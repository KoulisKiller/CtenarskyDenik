create database rozbor;
use rozbor;

create table autor(
id int primary key auto_increment not null,
jmeno varchar(50),
datum_narozeni date,
zivot varchar(255)
);

create table lit_druh(
id int primary key auto_increment not null,
typ varchar(20),
popis varchar(255)
);

create table lit_zanr(
id int primary key auto_increment not null,
typ varchar(20),
popis varchar(255),
id_litdruh int, foreign key (id_litdruh) references lit_druh(id)
);

create table lit_smer(
id int primary key auto_increment not null,
typ varchar(20),
popis varchar(255),
obdobi varchar(50)
);

create table kniha(
id int primary key auto_increment not null,
id_autor int, foreign key (id_autor) references autor(id),
id_zanr int,foreign key (id_zanr) references lit_zanr(id),
id_smer int,foreign key (id_smer) references lit_smer(id),
nazev varchar(100),
myslenka varchar(255),
kompozice varchar(50),
prostor varchar(50),
pozadi varchar(100)
);

commit;

select jmeno from autor;
select datum_narozeni from autor;
select zivot from autor;

select typ from lit_druh;
select popis from lit_druh;

select typ from lit_smer;
select popis from lit_smer;
select obdobi from lit_smer;

select typ from lit_zanr;
select popis from lit_zanr;
select lit_druh.typ, lit_zanr.typ from lit_druh join lit_zanr on lit_druh.id=lit_zanr.id_litdruh;

select nazev from kniha;
select myslenka from kniha;
select kompozice from kniha;
select prostor from kniha;
select pozadi from kniha;

create user "guest"@"%" identified by "123";