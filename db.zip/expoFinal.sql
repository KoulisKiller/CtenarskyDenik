-- MariaDB dump 10.19  Distrib 10.4.27-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: rozbor
-- ------------------------------------------------------
-- Server version	10.4.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `autor`
--

DROP TABLE IF EXISTS `autor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jmeno` varchar(50) DEFAULT NULL,
  `datum_narozeni` date DEFAULT NULL,
  `zivot` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autor`
--

LOCK TABLES `autor` WRITE;
/*!40000 ALTER TABLE `autor` DISABLE KEYS */;
INSERT INTO `autor` VALUES (1,'Charles Bukowski','1920-08-16','Neznámo'),(2,'Ray Bradbury','1920-08-22','Americký spisovatel sci-fi, fantasy a hororu.'),(3,'Milan Kundera','1929-04-01','Narodil se v Brně, studoval na filozofické fakultě, žil v Československu, Francie a USA. Jeho díla se často zabývají filozofickými otázkami a kritikou totalitního režimu.'),(4,'Václav Havel','1936-10-05','Havel byl český dramatik, esejistam disident a kritik komunistického režimu, politik a státník. Byl prezidentem.'),(5,'Eduard Petiška','1924-05-14','Eduard Petiška byl významným českým spisovatelem, který se specializoval na řeckou mytologii a dějiny. Studoval na univerzitách v Praze a v Paříži a věnoval se psaní knih a článků o řecké kultuře a filozofii.'),(6,'William Shakespeare','1564-04-01','William Shakespeare je považován za jednoho z nejvýznamnějších anglických dramatiků. Narodil se v roce 1564 v Stratfordu nad Avonem a zemřel v roce 1616. Během své kariéry napsal mnoho slavných her, jako je Hamlet, Macbeth, Othello a další.'),(7,'Jan Amos Komenský','1592-03-28','Narodil se v Nivnici, významný český humanista, teolog a pedagog, zakladatel moderního vzdělání'),(8,'Moliere','1673-02-17','Vlastním jménem Jean-Baptiste Poquelin. Narodil se v Paříži, významný francouzský dramatik, herec a režisér, představitel francouzského klasicismu'),(9,'Charles Dickens','1812-02-07','Narodil se v Portsmouthu, významný anglický spisovatel, známý pro své sociální romány'),(10,'Nikolaj Vasiljevič Gogol','1852-03-04','Ruský spisovatel, narodil se v Ukrajině, působil v Rusku'),(11,'Victor Hugo','1802-02-26','Francouzský spisovatel a básník, jedna z nejvýznamnějších osobností 19. století'),(12,'Karel Hynek Mácha','1810-11-16','Český básník, jedna z nejvýznamnějších osobností národního obrození'),(13,'Edgar Allan Poe','1809-01-19','Edgar Allan Poe byl americký romantický básník, prozaik, literární teoretik a esejista. Byl autorem zpravidla fantastických a mystických příběhů a zakladatelem detektivního a hororového žánru.'),(14,'George Bernard Shaw','1856-07-26','Irský dramatik a spisovatel, zakladatel moderního anglického dramatu'),(15,'Antoine de Saint-Exupéry','1900-06-29','Antoine de Saint-Exupéry byl francouzský spisovatel a letec, který se proslavil jako pilót v letech mezi světovými válkami.'),(16,'Franz Kafka','1883-07-03','židovským jménem Anšel, byl pražský německy píšící židovský spisovatel. Je považován za jednoho z literárně nejvlivnějších spisovatelů 20. století, byl členem Pražského kruhu.'),(17,'Jaroslav Hašek','1883-04-30','Jaroslav Hašek byl český spisovatel, publicista a novinář, autor druhé nejpřekládanější knihy české literatury, proslulých Osudů dobrého vojáka Švejka za světové války.'),(18,'Karel Čapek','1890-01-09','Karel Čapek byl český spisovatel, intelektuál, novinář, dramatik, překladatel a amatérský fotograf. Byl mladší bratr malíře a spisovatele Josefa Čapka.'),(19,'Karel Poláček','1892-03-22','Karel Poláček byl český spisovatel, humorista, novinář a filmový scenárista s židovskými kořeny.');
/*!40000 ALTER TABLE `autor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kniha`
--

DROP TABLE IF EXISTS `kniha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kniha` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_autor` int(11) DEFAULT NULL,
  `id_zanr` int(11) DEFAULT NULL,
  `id_smer` int(11) DEFAULT NULL,
  `nazev` varchar(100) DEFAULT NULL,
  `myslenka` varchar(255) DEFAULT NULL,
  `kompozice` varchar(50) DEFAULT NULL,
  `prostor` varchar(50) DEFAULT NULL,
  `pozadi` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_autor` (`id_autor`),
  KEY `id_zanr` (`id_zanr`),
  KEY `id_smer` (`id_smer`),
  CONSTRAINT `kniha_ibfk_1` FOREIGN KEY (`id_autor`) REFERENCES `autor` (`id`),
  CONSTRAINT `kniha_ibfk_2` FOREIGN KEY (`id_zanr`) REFERENCES `lit_zanr` (`id`),
  CONSTRAINT `kniha_ibfk_3` FOREIGN KEY (`id_smer`) REFERENCES `lit_smer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kniha`
--

LOCK TABLES `kniha` WRITE;
/*!40000 ALTER TABLE `kniha` DISABLE KEYS */;
INSERT INTO `kniha` VALUES (1,1,11,NULL,'Šunkový Nářez',NULL,NULL,NULL,NULL),(2,2,11,22,'451 stupňů Fahrenheita','Kritika společnosti a jejího vztahu k knihám a vzdělání, varování před totalitou a omezováním svobody.','Chronologický děj, časové a prostorové přeskoky.','V budoucnosti v americkém městě.','Studená válka.'),(3,3,12,21,'Žert','Kritika totalitního režimu a zkoumání lidského vztahů, identity, lásky a věrnosti','Vícevětový příběh s jednotlivými kapitolami','Praha, 60. léta 20. století','Československo v 60. letech 20. století, normalizace'),(4,4,25,21,'Audience','Dílo se zabývá tématem identity a otázkou, kdo jsme a jakým způsobem se naše identity utváří.','Dílo je rozděleno do jednotlivých scén, ve kterých','Přesný čas a místo děje není v díle určeno.','Dílo vychází z období normalizace v Československu, kdy byla cenzura silně kontrolována a kdy byly n'),(5,5,17,NULL,'Staré řecké báje a pověsti','Kniha představuje řeckou mytologii jako důležitý zdroj informací o starověké řecké kultuře a filozofii. Tyto příběhy slouží jako symbolické vyjádření řeckých náboženských a filozofických','Kniha se skládá z řady oddělených příběhů, které j','Příběhy se odehrávají v starověkém Řecku a většina','Starověké Řecko je považováno za jedno z nejvýznamnějších a nejvlivnějších období v dějinách starého'),(6,NULL,NULL,NULL,'Podkoní a žák','Autor zobrazuje vztah mezi nadřízeným a podřízeným, kde dochází k osobnímu růstu a změně postojů obou postav. Také se zde diskutuje o otázkách spravedlnosti a nespravedlnosti.','Lineární, chronologický vývoj děje','V hospodě','Kniha \"Podkoní a žák\" byla napsána v době, kdy bylo obyčejné, že existovala silná hierarchie mezi na'),(7,6,21,1,'Romeo a Julie','Hlavním tématem je láska a nenávist, které se prolínají a ovlivňují osudy hlavních postav. Dále se kniha zabývá tématy jako jsou tradice, rodinné vztahy a konflikty mezi mladými a staršími generacemi.','Tragický příběh o lásce, nenávisti a rodinných spo','Verona, 15. století','Drama \"Romeo a Julie\" bylo napsáno v době renesance, kdy se objevilo mnoho nových nápadů a hodnot. B'),(8,6,21,1,'Hamlet','Smrt, sebevražda, žal, zrada, zkorumpovanost, hledání pravdy a odpovědnosti','Linearní, střídání dialogy a monologů','Dánsko, středověk','Tudorovské období v Anglii'),(9,6,20,1,'Zkrocení zlé ženy','Manželství, genderové role, moc a vliv, láska a oddanost, žert a humor','Linearní, střídání dialogy a monologů','Itálie, středověk','Tudorovské období v Anglii'),(10,7,11,2,'Labyrint světa a ráj srdce','Náboženství, vzdělání, společenské problémy, filozofie života, vize nového světa','Tematická, vyprávění, diskuse','17. století, Česká země','Reformační doba v Čechách'),(11,8,20,3,'Lakomec','Kritika společenských nedostatků, zejména chamtivosti a materialismu','Dialogická, vyprávění','17. století, Francie','Francouzský absolutismus'),(12,9,11,7,'Oliver Twist','Kritika společenských nedostatků, zejména chudoby a zneužívání dětí v průmyslu','Vyprávění z pohledu vševědoucího narrátora','19. století, Londýn, Anglie','Industrializace, viktoriánská éra'),(13,10,20,7,'Revizor','Kritika moci a korupce ve společnosti','Dialogy a jednání mezi postavami','Nezmiňuje se, může být kdekoli a kdykoli','Francouzská revoluce, napoleonské období'),(14,11,11,7,'Ubožáci',' Kritika společenských a sociálních poměrů, lidská práva, lidská důstojnost','Příběh s přímou a výpovědí','Paříž a okolí v 19. století','Francouzská revoluce, napoleonské období, industriální éra'),(15,12,26,6,'Máj','Láska, touha po dokonalosti a štěstí, kritika společnosti a jejích hodnot','Epická báseň s využitím lyrických pasáží','Příroda, symbolický čas','Období národního obrození v Českých zemích'),(16,13,26,11,'Havran','Smrt, konec, odchod','Samostatná báseň','Symbolický','Světový romantismus'),(17,15,18,21,'Malý Princ',' Kniha hlouběji zkoumá otázky lidské existence, lásky, přátelství a odpovědnosti.','Kniha se skládá ze vzpomínek hlavního hrdiny, Malé','Kniha se odehrává na několika planetách a v mezihv','Byla napsána v období mezi dvěma světovými válkami.'),(18,16,13,18,'Proměna','Řehoř Samsa a jeho boj v bezvýchodné situaci','Vyprávění se střídají dialogy mezi hlavními postav','V Čechách v druhé polovině 19. století','Počátek 20.století'),(19,14,20,7,'Pygmalion',' Kritika společenských tříd, jazyka a vzdělání, přeměna osobnosti','Chronologická, restrospektivní','Londýn, konec 19. století','Industrializace a urbanizace v Anglii, rozvoj vědy a techniky'),(20,17,11,21,'Osudy dobrého vojáka Švejka za války','Kritika vojenského a politického systému, ironie, absurdita a bezmocnost běžného člověka v konfliktu','Chronologická, restrospektivní','Československo, 1. světová válka','1. světová válka, počátky československého státu, politické situace v Československu'),(21,18,NULL,21,'R.U.R.','Kritika společnosti, otázky lidskosti, týkající se rozvinutí techniky, otázka životaschopnosti umělých bytostí','Chronologický vývoj, využití dialogů a monologů',' Futuristická společnost, blízká budoucnost','Přelom 19. a 20. století, vývoj techniky, industriální revoluce, první světová válka'),(22,19,11,21,'Bylo nás pět','Autor zobrazuje život rodiny a výchovu dětí s nadsázkou a ironií. Ukazuje i téma společenského poměru v tehdejší době.','Dílo je rozděleno do kapitol, které vyprávějí o ži','Časový úsek díla je těsně před druhou světovou vál','Dílo se odehrává v době první republiky a nastínil výchovu a život v rodině.');
/*!40000 ALTER TABLE `kniha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lit_druh`
--

DROP TABLE IF EXISTS `lit_druh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lit_druh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typ` varchar(20) DEFAULT NULL,
  `popis` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lit_druh`
--

LOCK TABLES `lit_druh` WRITE;
/*!40000 ALTER TABLE `lit_druh` DISABLE KEYS */;
INSERT INTO `lit_druh` VALUES (1,'Lyrika','Autor do díla zakomponuje subjektivní pocity. Vyznačuje se tím,že nemá děj. Setkat se s ní můžeme v poezii.'),(2,'Epika','Epika je založená na ději. Obvykle vystupují postavy.'),(3,'Drama','Drama vzniklo ve starověkém Řecku v průběhu pátého století před n.l. Vyvinulo se ze slavností na počest boha Dionýsa. Představení se hraje na jevišti.');
/*!40000 ALTER TABLE `lit_druh` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lit_smer`
--

DROP TABLE IF EXISTS `lit_smer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lit_smer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typ` varchar(20) DEFAULT NULL,
  `popis` varchar(255) DEFAULT NULL,
  `obdobi` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lit_smer`
--

LOCK TABLES `lit_smer` WRITE;
/*!40000 ALTER TABLE `lit_smer` DISABLE KEYS */;
INSERT INTO `lit_smer` VALUES (1,'Renesance','Návrat k antické kultuře, poznání člověka. Pocit sebevědomí jednotlivce.','14.-17.stol'),(2,'Baroko','Vzrůstá síla kat.církve, lidé věří v nadpozemský život.','období po třicetileté válce'),(3,'Klasicismus','Krása je v pravdě a obrazu přírody. kolébkou je Francie, antické vzory.','2.pol.17.stol.-18.stol.'),(4,'Preromantismus','Přechod mezi klasicismem a romantismem, důraz na cit, odmítnutí konvencí, návrat k přírodě, vzor venkova a prostosti.','pol.18.stol.'),(5,'Národní Obrození','Zájem o český jazyk, rozvoj divadla.','70.léta 18.stol.-50.léta.19.stol.'),(6,'Romantismus','Důraz na cit a fantasii, rozpor mezi představou a skutečností, vyjimečný hrdina','1.pol.19.stol.'),(7,'Realismus','Pravdivý obraz skutečnosti, hrdina a děj se vyvíjí, kritika společnosti.','2.pol.19.stol.'),(8,'Naturalismus','Vliv dědičnosti a prostředí, popírá se lidská vůle, výchova a svoboda. Hrdinové z nejnížších vrstev.','2.pol.19.stol.'),(9,'Impresionismus','lyričnost a hudebnost verše, intimní a přírodní poezie, popisování emocí a nálad.','konec 19.stol-začátek 20.stol.'),(10,'Dekadence','pocity marnosti, nudy, prázdnoty, klamání a beznaděje jednotlivce.','konec 19.stol-začátek 20.stol.'),(11,'Symbolismus','Rozvoj básnické obraznosti a důraz na hudebnost, básník se snaží zapůsobit na úkor pochopení.','konec 19.stol-začátek 20.stol.'),(12,'Vitalismus','Oslavuje život.','1.pol.20.stol'),(13,'Expresionismus','Soustředí se na citové stavy, projevy lidské psychiky, které vyplývají z nejistoty člověka v chaotickém světě.','1.pol.20.stol'),(14,'Dadaismus','Spontání. Hlavní princip je náhoda.','1.pol.20.stol'),(15,'Surrealismus','Tvorba založená na podvědomí, snech.','1.pol.20.stol'),(16,'Kubismus','Důraz kladen na dynamiku a fantasii.','1.pol.20.stol'),(17,'Ztracená generace','Spisovatelé zažili 1.svět.válku. ','1.pol.20.stol'),(18,'Existencialismus','Člověk jako individuum, odloučený od společnosti a bez vazeb.','1.pol.20.stol'),(19,'Proletářská poezie','Inspirace dělníky. Snaha vystihnout jejich bídný život. Snaha poukázat na sociální nespravedlnosti.','1.pol.20.stol'),(20,'Poetismus','Volná asociace. Motivem je exotika, cestování.','1.pol.20.stol'),(21,'Literatura 2.pol.20.','Odraz války, vědecko-fantastická literatura','2.pol.20.stol.'),(22,'Dystopie','Fiktivní společnost, co se vyvinula špatným směrem.',NULL);
/*!40000 ALTER TABLE `lit_smer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lit_zanr`
--

DROP TABLE IF EXISTS `lit_zanr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lit_zanr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typ` varchar(20) DEFAULT NULL,
  `popis` varchar(255) DEFAULT NULL,
  `id_litdruh` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_litdruh` (`id_litdruh`),
  CONSTRAINT `lit_zanr_ibfk_1` FOREIGN KEY (`id_litdruh`) REFERENCES `lit_druh` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lit_zanr`
--

LOCK TABLES `lit_zanr` WRITE;
/*!40000 ALTER TABLE `lit_zanr` DISABLE KEYS */;
INSERT INTO `lit_zanr` VALUES (1,'Hymnus',NULL,1),(2,'Óda',NULL,1),(3,'Sonet',NULL,1),(4,'Píseň',NULL,1),(5,'Elegie','Žalozpěv',1),(6,'Villonská balada',NULL,1),(7,'Epigram',NULL,1),(8,'Přísloví',NULL,1),(9,'Cestopis',NULL,1),(10,'Epos',NULL,2),(11,'Román',NULL,2),(12,'Novela',NULL,2),(13,'Povídka',NULL,2),(14,'Bajka',NULL,2),(15,'Legenda',NULL,2),(16,'Mýtus',NULL,2),(17,'Pověst',NULL,2),(18,'Pohádka',NULL,2),(19,'Kronika',NULL,2),(20,'Komedie',NULL,3),(21,'Tragédie',NULL,3),(22,'Fraška',NULL,3),(23,'Opera',NULL,3),(24,'Muzikál',NULL,3),(25,'Tragikomedie',NULL,3),(26,'Báseň',NULL,1);
/*!40000 ALTER TABLE `lit_zanr` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-16 15:47:17
