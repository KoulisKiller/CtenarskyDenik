<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class PetController extends AbstractController {
        
    public function pet(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Bylo nás pět</h1>
            <p>
            Literární druh a žánr: Próza<br>
            Literární směr: Próza 20. století, humoristický žánr<br>
            Slovní zásoba a jazyk: Jazyk díla je srozumitelný a běžný.<br>
            Hlavní postavy: Josef, Marie, Toník, Anička, Hanička<br>
            Kompozice: Dílo je rozděleno do kapitol, které vyprávějí o životě rodiny v období první republiky.<br>
            Prostor a čas: Časový úsek díla je těsně před druhou světovou válkou, děj se odehrává v Praze.<br>
            Význam sdělení (hlavní myšlenky díla): Autor zobrazuje život rodiny a výchovu dětí s nadsázkou a ironií. Ukazuje i téma společenského poměru v tehdejší době.<br>
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Dílo se odehrává v době první republiky a nastínil výchovu a život v rodině.<br>
            <br>
            </p>
            <p>děj:<br>"Bylo nás pět" je román od britské spisovatelky Enid Blytonové. Kniha je založena na dobrodružstvích pěti sourozenců, Juliany, Dicka, Georgie, Ann a Timmyho, kteří žijí v domečku v lese. Kniha následuje jejich dobrodružství, při nichž řeší různé záhady a pomáhají tam, kde je to potřeba. "Bylo nás pět" je ztělesněním dětské fantazie a touhy po dobrodružství a je dodnes oblíbenou knihou pro děti a mládež.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>