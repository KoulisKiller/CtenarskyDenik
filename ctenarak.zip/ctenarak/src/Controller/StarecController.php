<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class StarecController extends AbstractController {
        
    public function starec(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Stařec a Moře</h1>
            <p>Literární druh a žánr: Próza, novela
            Literární směr: Realismus
            Slovní zásoba a jazyk: Prostý, srozumitelný jazyk
            Hlavní postavy: Santiago, starý rybář
            Kompozice: Linearní, chronologická
            Prostor a čas: Kubánské moře, současnost
            Význam sdělení (hlavní myšlenky díla): Odhodlání, boj o přežití, hledání smyslu života
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Druhá světová válka, Kubánská revoluce
            
            děj:Hlavního hrdinu knihy, rybáře Santiaga, začíná trápit jeho smůla, kdy už mnoho dní po sobě neulovil žádnou rybu a takřka nemá z čeho jíst. Na rozkaz rodičů ho musí opustit i jeho pomocník chlapec Manolin. Ten se o něho staral, dával mu jídlo a pomáhal mu na moři. Jednoho dne se stařec rozhodne vyjet na moře, kde ještě nikdo nebyl a loučí se s chlapcem, kterého nechává ve vesnici. Po několika neúspěšných dnech na vodě chytí vysněný úlovek. Neví sice, jak vypadá, ale podle chování ryby pozná, že je to jeho snad největší úlovek. Ryba ho však překvapí svou silou a začne ho táhnout na otevřené moře. Stařec se ji snaží zadržet, je však starý a po několika hodinách svůj boj vzdává. Ryba ho vytrvale táhne dál a stařec je velmi vyčerpán a unaven, nepouští ji však z lodě, protože věří, že se jednou unaví a on ji bude moct zabít. To se mu - díky svým zkušenostem - podaří, přiváže ji k loďce a podle slunce míří zpět domů. Po cestě ale musí odolávat útokům žraloků na jeho loď. I přes velkou odhodlanost starce mu jeho úlovek sežerou. Naprosto vyčerpaný stařec dorazí domů, loďku nechá přivázanou u mola a ráno se kolem ní shromáždí dav lidí, aby se podíval na obrovitou kostru ryby přivázanou na starcově loďce.
            </body>
            </html>'
        );
    }
}
?>