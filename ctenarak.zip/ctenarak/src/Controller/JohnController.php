<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class JohnController extends AbstractController {
        
    public function john(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>John Wyndham</h1>
            <p>Život autora: britský spisovatel science fiction, narozen 1902, zemřel 1969
            Autorovo další dílo: "Planeta bez návratu", "Návrat ztracených", "Sběrač mraků"
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: George Orwell, Aldous Huxley, H.G. Wells.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>