<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class IvanController extends AbstractController {
        
    public function ivan(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Ivan Olbracht</h1>
            <p>Život autora: Ivan Olbracht (1882-1952) byl český spisovatel a novinář, patří k významným představitelům českého realismu.
            Autorovo další dílo: "Rozmarné léto", "Ze života hmyzu", "Válka s mloky".
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Karel Čapek, Vladislav Vančura, Alois Jirásek.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>