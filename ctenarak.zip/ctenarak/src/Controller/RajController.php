<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class RajController extends AbstractController {
        
    public function raj(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Labyrint světa a ráje srdce</h1>
            <p> Literární druh a žánr: Esej, náboženský traktát
            Literární směr: Baroko
            Slovní zásoba a jazyk: Barokní čeština, velká slovní zásoba, bohatá na metaforické a symbolické prvky
            Hlavní postavy: Jan Amos Komenský
            Kompozice: Tematická, vyprávění, diskuse
            Prostor a čas: 17. století, Česká země
            Význam sdělení (hlavní myšlenky díla): Náboženství, vzdělání, společenské problémy, filozofie života, vize nového světa
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Reformační doba v Čechách<br>
            </p>
            <p>děj:<br>Autor (poutník – vypravěč) se rozhodl prozkoumat svět, aby zjistil, jaký je smysl a cíl všeho lidského snažení a jaké povolání a místo ve světě si má vybrat. Svět je zobrazen alegoricky jako město, které připomíná labyrint a jímž prochází.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>