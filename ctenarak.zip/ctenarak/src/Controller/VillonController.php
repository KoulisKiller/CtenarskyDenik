<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class VillonController extends AbstractController {
        
    public function villon(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Francois Villion</h1>
            <p>ŽIVOT AUTORA: Francois Villion byl francouzský spisovatel a novinář, který se narodil v roce 1820. Jeho život a kariéra byly silně ovlivněny politickými a společenskými změnami ve Francii.

            AUTOROVO DALŠÍ DÍLO: Kromě knihy "Závěť" není o dalších dílech autora dostupná žádná informace.
            
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Ve stejném období působili jiní francouzští autoři jako například Gustave Flaubert, Honore de Balzac a další, kteří se zabývali tématy jako je lidský život a jeho složitost, společenský a politický pluralismus a otázky svobody a rovnosti. Tyto autority se staly významnými představiteli realistického žánru a dodnes představují významný zdroj informací o tehdejší francouzské společnosti.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>