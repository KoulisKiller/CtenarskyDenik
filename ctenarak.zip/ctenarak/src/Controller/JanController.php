<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class JanController extends AbstractController {
        
    public function jan(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Jan Amos Komenský</h1>
            <p>Život autora: Narodil se v Nivnici, významný český humanista, teolog a pedagog, zakladatel moderního vzdělání
            Autorovo další dílo: Mnoho dalších spisů jako je Pedagogická polemika, Cesty nebeské
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Karel Havlíček Borovský, Alois Jirásek, Jan Neruda.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>