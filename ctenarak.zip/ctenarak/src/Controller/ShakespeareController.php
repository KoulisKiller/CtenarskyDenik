<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ShakespeareController extends AbstractController {
        
    public function shakespeare(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>William Shakespeare</h1>
            <p>Život autora: Narodil se v Stratfordu nad Avonem, považován za nejvýznamnějšího dramatika všech dob, žil a psal v době kulturního a uměleckého rozkvětu v Anglii
            Autorovo další dílo: Mnoho dalších slavných her jako je Napoleón, Jindřich IV, Macbeth, Sen noci svatojánské
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Christopher Marlowe, Ben Jonson, Thomas Kyd.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>