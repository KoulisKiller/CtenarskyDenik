<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class VolbaController extends AbstractController {
        
    public function volba(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Sophiina volba</h1>
            <p>
            Literární druh a žánr: Próza
            Literární směr: Sociálně-kritický realizmus
            Slovní zásoba a jazyk: Prostý, srozumitelný jazyk s využitím dialektismů a lidové mluvy.
            Hlavní postavy: Sophia, Connie, Gilbert, Louisa, Caroline, Nathan
            Kompozice: Chronologická, s časovými skoky
            Prostor a čas: 20. století, ruralní oblast v Severní Karolíně
            Význam sdělení (hlavní myšlenky díla): Autor v knize zobrazuje konflikt mezi tradičními hodnotami a moderními pohledy na svět, a také otázku volby a odpovědnosti jednotlivce.
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Kniha se odehrává v době velkých sociálních změn v USA.
            
            děj: Rozsáhlý mnohovrstevnatý román, který poprvé vyšel již v roce 1979, začíná okamžikem, kdy se Stingo, mladý jižanský spisovatel, přistěhuje do brooklynského penzionu, aby tam pracoval na svém románu. Brzy však začne být téměř proti své vůli vtahován do citového dramatu, které se odehrává mezi jeho sousedy, Nathanem a Sophií. Neurotický, přecitlivělý Žid Nathan se zjevně propadá stále hlouběji do zničující duševní choroby a krásná Polka Sophie, která prošla Osvětimí, je navždy poznamenaná prožitým utrpením. Zatímco Stingo sleduje, jak během jediného manhattanského léta a podzimu osudy Sophie a Nathana směřují ke svému nevyhnutelnému tragickému závěru, poslouchá Sophiino vyprávění o minulosti, z něhož se po částech vynořuje děsivý, krutě realistický obraz společenského zla, které páchá nenapravitelné škody na lidské duši. Prostřednictvím psychologické drobnokresby a precizní, široce epické malby charakterů i prostředí obnažuje autor otázky viny, kolektivní odpovědnosti a povahy zla, ať už jde o původ a projevy nacismu za druhé světové války, nebo o americké trauma a stigma otrokářské minulosti. Sophiina volba tak zůstává i více než dvacet let po svém prvním vydání nejen románem s trvalou literární hodnotou, ale i textem, který jde až na dřeň v analýze banálního zla, jež se v mezních situacích tak rychle mění ve zlo radikální.
            </body>
            </html>'
        );
    }
}
?>