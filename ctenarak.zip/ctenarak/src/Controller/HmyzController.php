<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class HmyzController extends AbstractController {
        
    public function hmyz(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Ze života hmyzu</h1>
            <p>
            Literární druh a žánr: Beletrie, sci-fi
            Literární směr: Próza, socialistický realismus
            Slovní zásoba a jazyk: Prostý, srozumitelný jazyk
            Hlavní postavy: Bezjmenní hmyzí postavy
            Kompozice: Chronologický vývoj děje
            Prostor a čas: Nekonkrétní, imaginární svět hmyzu
            Význam sdělení (hlavní myšlenky díla): Kritika lidské společnosti a kapitalistického způsobu života, poukaz na nutnost solidarity a bratrství
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Období první světové války a meziválečného období v Československu
            
            děj:V prvním jednání se ocitneme ve společnosti pěti motýlů. Mezi dvěma páry a jedním, který se stal básníkem. Samičky neboli družky nevydrží dlouho vždy jen se svým partnerem, a tak si je střídají, jak chtějí. Iris odlétá s partnerem Clythie, s Otakarem. Když po nějaké době přilétá Iris zpět, přináší s sebou zprávu, že jejího bývalého partnera, Viktora, sežral pták, a stěžuje si, že bude muset snášet Otakarova vajíčka. Vajíčka byla výsledkem Otakarovy lásky. Chudák Clythie odlétá pryč hledat si svého nového muže, aby mohla být zase též milována, na nějakou dobu... Chudák motýl básník, zůstal sám a žádnou samičku na své básně nenalákal, nebyl totiž dobrým básníkem.
            
            Ve druhém jednání tu máme rodinku chrobáků, která si valí jednu kuličku před sebou a hledá pro ni důlek, aby mohli válet další. Kulička je pro ně celým svým životem. Samička chrobáka opustí kuličku, jíž hlídá, než se vrátí manžel, a jde se podívat po důlku. Mezitím jim tu kuličku další chrobák ukradne, a stává se tak jeho majetkem. Stejný jako chrobáci je i cvrček, ten se chtěl se svojí ženou přestěhovat do domku, který dříve patřil jinému cvrčkovi, jehož zabil pták. Když jde cvrček na obcházku domu, zabije mu ženu mezitím lumek, a když se cvrček vrací za ženou, tak i on se stává objetí lumka. Lumek byl skrblík, zabíjel cvrčky, aby se jeho dceruška mohla napapat, a zabíjel je i do zásoby. Nakonec se jeden parazit na louce naštve, má totiž hlad a před ním má lumek spižírnu ze cvrčků. Tak se tam vkrade, sní cvrčky a i dcerušku larvičku (larvičku lumka). Během jednání se na pastvině tulák rozpráví s kuklou, jež neustále říkala, že se stane něco velkého.
            
            Třetí jednání pojednává o mravencích, kteří drží pospolu a záleží jim na celku a svém národu. Pracují v rychlém tepu, který udává slepý mravenec. Při práci někteří mravenci hynou. Mravenci touží o velkém území, a tak vedou válku se svými žlutými druhy. Vypadá to nadějně, že válku vyhrají, ale stejně nakonec zvítězí žlutí mravenci. Vůdce mravenců stále mluví o národnostním právu, a tak ho tulák zašlápne. Zemřelo kvůli němu hodně mravenců.
            
            Konec knížky tvoří epilog. Tulák se ocitne v naprosté tmě a hledá světlo, ale nikde ho nemůže najít. Pak se najednou objeví světla a s ním radostný tanec jepic, které během chvilky uhynou, ale stihly si užít života, naklást vajíčka a ještě zemřít. V jepici se vylíhne i ta kukla z druhého jednání a též zahyne. Tulák je šokován, že tolika jepic zemřelo; i ta jeho kamarádka. Nejen jepice umírají, ale smrt si jde i pro tuláka. Vše pozorují dva slimáci, kteří jsou jakoby diváky. Když jdou kolem dřevorubci a najdou mrtvolu, začnou o tom diskutovat; vtom spatří tetu, která jde s dítětem ke křtu. Dřevorubci si řeknou: "Jeden se narodí a druhý zemře."
            
            Na konci knížky si můžeme přečíst alternativní konec: Když tulák zemře ve třetím dějství, epilogem pak je, že se probudí a zjišťuje, že se mu to vše jen zdálo. Když jdou kolem dva dřevorubci a vyptávají se ho, co tu dělá, řekne jim, co je zač. Dřevorubci jsou tak laskaví, že mu nabídnou práci, a tak tulák dostane práci a konečně někam patří...
            
            
            
            </body>
            </html>'
        );
    }
}
?>