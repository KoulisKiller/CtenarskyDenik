<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class PygmalionController extends AbstractController {
        
    public function pygmalion(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Pygmalion</h1>
            <p>
            Literární druh a žánr: Drama
            Literární směr: Realismus
            Slovní zásoba a jazyk: Výstižný jazyk, využití dialektů
            Hlavní postavy: Henry Higgins, Eliza Doolittle, Freddy Eynsford-Hill, Pickering
            Kompozice: Jednoduchý děj s časovými změnami a výměnou dialogů
            Prostor a čas: Londýn, konec 19. století
            Význam sdělení (hlavní myšlenky díla): Kritika společenských tříd, jazyka a vzdělání, přeměna osobnosti
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Industrializace a urbanizace v Anglii, rozvoj vědy a techniky
            
            děj:Londýnský profesor fonetiky Henry Higgins jednou náhodně potká Lízu Doolittlovou, která na ulici prodává květiny. Vsadí se s plukovníkem Pickeringem, znalcem indických jazyků, že je schopný z chudé dívky na okraji společnosti, která nemá o spisovné řeči a správné výslovnosti ani ponětí, udělat do 6 měsíců dámu, a to jak mluvou, tak i chováním. Líza se to tedy rozhodne zkusit.
            Ve společnosti těchto dvou vzdělanců se denně po šest měsíců učí správné výslovnosti. Je velmi bystrá a učí se rychle. Oblíbí si ji paní Higginsová, matka profesora, u níž se také seznámí s mladíkem Freddym, který se do ní zamiluje.
            
            Po půlroce se Líza s plukovníkem a profesorem vydá na večírek do Buckinghemského paláce, kde ji všichni pokládají za maďarskou šlechtičnu a nikoho ani nenapadne, že tato dívka byla ještě před pár měsíci chudá a ušpiněná květinářka, které by si na ulici ani nevšimli. Profesor Higgins a plukovník Pickering se radují, že experiment mají za sebou, že uspěli a že za půl roku dokázali Lízu úplně změnit, ale ta se s nimi pohádá, neboť si najednou uvědomuje, že nemá kam jít, protože se nemůže vrátit na ulici po tom, jak se za tu dobu změnila. Odejde tedy k matce profesora Higginse a rozhodne se provdat za Freddyho. Za pomoci plukovníka Pickeringa si otevře květinářství a splní si tím životní sen.
             </body>
            </body>
            </html>'
        );
    }
}
?>