<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class HovnoController extends AbstractController {
        
    public function hovno(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Hovno Hoří</h1>
            <p>Hovno hoří
            Hovno hoří je sbírka povídek Petra Šabacha z roku 1994. Na motivy knihy byl v roce 1999 natočen film Pelíšky.
            Název je převzat z prologu, jenž popisuje rozdíl mezi dvěma světy, světem mužským a ženským, 
            a především rozdíl mezi dvěma pohledy na život a na svět. Děvčata jedoucí autobusem z Paříže 
            nadšeně rozjímají nad nákupy a plyšáky, dva obrýlení chlapci celou cestu "seriózně" řeší problém, 
            zda hovno hoří… Rozděluje je sice jen úzká ulička mezi sedadly, ale symbolicky je rozděluje podstatně větší,
             mnohdy nepřekonatelný příkop. Kniha obsahuje tři prozaické texty – povídky Sázka a Bellevue a novelu Voda se šťávou.
             Některé scény z novely Voda se šťávou byly zapracovány do filmů Pelíšky a Pupendo a podle novely 
             vznikl také stejnojmenný krátkometrážní studentský film Jaroslava Pauera. Děj knihy částečně vychází z autorových životních zkušeností, 
            obsahuje mnoho autobiografických prvků. Kniha byla vytvořena metodou „vlaštovčího hnízda" 
            (tak ji nazval sám Šabach), ta spočívá v tom, že autor přidává k hlavnímu ději různorodé povídky.
            děj:Hovno hoří je považováno za úspěšné dílo Petra Šabacha, jednoho z nejznámějších současných českých prozaiků. Knížka obsahuje celkem tři povídky, které mají společné téma - vztahy mezi mužem a ženou a jejich rozdílné vnímání okolního světa.
            
            
            
            Je zde pohled autora, tedy muže, a povídky jsou protkávány připomínkami jeho ženy Anny, která sloužila jako předloha k jedné z hlavních postav. Kniha se dělí do tří částí: Sázka, Bellevue (krásná vyhlídka) a Voda se šťávou.
            
            V Sázce autor vypráví o tom, jak jednou seděl v hospůdce, kde se kochá pohledem na dva staré dědečky, kteří se neustále hádají a chtějí si něco dokazovat. Po předvedení, že medvěd kodiak může mít tři metry a poté, co jeden z nich vydrží dvě minuty pod vodou, odcházejí z hospody jako největší přátelé.
            Bellevue popisuje neobyčejný den obyčejných lidí, kteří bydlí v krásném domě s vyhlídkou, kde se odehrávají příběhy kováře a jeho ženy, jeho dvou synů, dcery a dědečka.
            Pro maminku je to další ze stereotypních dnů, ale kováři tak nepřijde, protože musí okovat koně, jehož se bojí. Starší syn přemýšlí nad svými problémy týkajících se dívek, mladší syn se vyrovnává s tím, že se stále ve třetí třídě počůrává, malou holčičku trápí to, že ji nikdo neposlouchá a dědečka močové kameny.
            V kapitole Voda se šťávou je popisován život malého kluka, jenž postupně dospívá v mladého muže. Petr je oddaným pionýrem, snaží se poslouchat svého otce straníka, ale postupem času zjišťuje, že strana není to, co by mělo navždy patřit do jeho života. V pubertě se začíná bouřit. Nechá si narůst dlouhé vlasy a změní se i jeho postoje a názory ke světu, které mu částečně pomáhá dotvářet jeho starší bratr (flákač a žrout jablek). Jeho život stále ovlivňuje dlouhovlasá Andulka s velkýma hlubokýma očima, které ho navždy uchvátily.
            Andulka postupem času zjišťuje, jak to s ní je v životě, kde má své místo, jak zapůsobit na ostatní, aby dostala to, po čem nejvíce touží. Dospívá v krásnou ženu se stále stejnýma hlubokýma hnědýma očima, které měla už i ve svém raném věku jako roztomilá Andulka. Anička je člověk s neustálou potřebou pomáhat, jako malá dostala od svého tatínka panenku, tedy spíše mrkacího černouška, ale přesto byla velmi šťastná. Začala se o něj starat, převlékala ho do různých oblečků, vrtala mu zoubky a nahrazovala je plombami z mouky a vyvrtala mu dírku do bříška, aby se mohl počůrat a ona mu mohla vyhubovat. S Petrem se poprvé setkali po maturitě a po šesti letech chození se vzali, aby ho mohla navždy opečovávat.
            
            Četl jsem od Šabacha i jiné tituly jako Opilé banány, Zvláštní problém Františka S. nebo Občanský průkaz. Téma zůstává stále stejné, autor se snaží ve svých knihách zavzpomínat na dobu, kdy byl mladý a musel snášet mnoho rozmarů tehdejšího režimu, ale nezapomíná na humor, jenž nechybí v žádné jeho knize, na hospody, kamarády, ale především na ženy, které má tolik rád. Ve srovnání s filmem, kde je divákovi více předkládán obraz tehdejšího režimu, Šabach čtenáři ukazuje krásy života a především humor, který by měl každý hledat.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>