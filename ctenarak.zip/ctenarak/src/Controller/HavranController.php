<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class HavranController extends AbstractController {
        
    public function havran(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Havran</h1>
            <p>Literární druh a žánr: Báseň
            Literární směr: Symbolismus
            Slovní zásoba a jazyk: Symbolický jazyk, využití obrazů a metafor
            Hlavní postavy: Havran
            Kompozice: Samostatná báseň
            Prostor a čas: Symbolický
            Význam sdělení (hlavní myšlenky díla): Smrt, konec, odchod
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Období symbolizmu v české literatuře<br>
            </p>
            <p>děj:<br>Baladická báseň Havran, jejíž refrén "Nikdy víc" umocňuje hrůzu z konečnosti a muk života vychází s autorovou esejí "Filosofie básnické skladby. " Poe v ní vykládá postup, jímž došel od prvního záměru ke konečnému znění této světoznámé básně. Připojen výbor z ostatních, tragicky laděných a senzitivních veršů tohoto velikého amerického romantika 19. stol.
            Filosofii básnické skladby [z angl. The Philosophy of composition] přel. Aloys Skoumal ; František Götz: Tragický lyrik Havrana, Edgar Allan Poe, doslov</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>