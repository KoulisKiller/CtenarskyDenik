<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class MajController extends AbstractController {
        
    public function maj(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Máj</h1>
            <p>Literární druh a žánr: Báseň, lyricko-epická báseň
            Literární směr: Romantismus
            Slovní zásoba a jazyk: Čeština, klasický jazyk s využitím lyrických obrazů
            Hlavní postavy: Hrdina, kráska
            Kompozice: Epická báseň s využitím lyrických pasáží
            Prostor a čas: Příroda, symbolický čas
            Význam sdělení (hlavní myšlenky díla): Láska, touha po dokonalosti a štěstí, kritika společnosti a jejích hodnot
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Období národního obrození v Českých zemích<br>
            </p>
            <p>děj:<br>Dílo Karla Hynka Máchy má prostý děj. Začíná Jarmilinou tragédií, když se mladá dívka utopí ze zoufalství nad osudem svého milého - Viléma. Vilém je v mládí otcem zanechám v lese. Vyrůstá mezi loupežníky a stane se jejich vůdcem (přezdívají mu Strašný lesů pán). Je velmi žárlivý a pomsty chtivý, zavraždí svého soka v lásce a až poté se dozvídá, že se dopouští otcovraždy. Vilém je popraven. V závěru pozurujeme návrat poutníka, autora, který se po letech vrací na místo Vilémovy popravy.
            Celou básní o 4 zpěvech a 2 intermezzech nás provází silný kontrast mezi lidským životem a přírodou. Při popisu přírody je zřejmá barvitost, citová působivost, pohyb a napětí.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>