<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class OrwellController extends AbstractController {
        
    public function orwell(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>George Orwell</h1>
            <p>Život autora: anglický spisovatel a publicista, známý pro své kritické postoje k vládnutí a totalitním režimům
            Autorovo další dílo: 1984, Zvíře farmy, Homage to Catalonia
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Aldous Huxley, John Steinbeck, Jack London.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>