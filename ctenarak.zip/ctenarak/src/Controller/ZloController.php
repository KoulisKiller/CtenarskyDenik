<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ZloController extends AbstractController {
        
    public function zlo(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Květy Zla</h1>
            <p>Literární druh a žánr: Lyrika
            Literární směr: Symbolismus
            Slovní zásoba a jazyk: Výstižný jazyk, využití obrazného jazyka
            Hlavní postavy: Autor, jeho blízcí, společnost
            Kompozice: Sbírka veršů s tematikou zla, temnoty, násilí a lásky
            Prostor a čas: Paříž, 19. století
            Význam sdělení (hlavní myšlenky díla): Kritika společnosti a jejího moralismu, hledání identity a smyslu života
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Francouzská revoluce, Paříž 19. století
            <br>
            </p>
            <p>děj:<br> Reprezentativní výbor z básnické sbírky v překladech Otokara Fischera, Viktora Dyba, Karla Čapka, Hanuše Jelínka, Zdeňka Kalisty, Vladimíra Holana a Františka Hrubína.
            Slavná sbírka veršů, vydaná poprvé v r. 1857, která v době svého vzniku vzbudila nesmírné pohoršení měšťácké společnosti. Sbírku tvoří 6 částí: Spleen a ideál, Pařížské obrazy, Víno, Květy zla, Vzpoura a Smrt. V básních je zcela obnaženo srdce člověka, rozpolceného mezi hrůzou před životem a extází z jeho krásy, člověka, který je nepřítelem každé prostřednosti a všednosti, se zálibou ve výstřední obraznosti.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>