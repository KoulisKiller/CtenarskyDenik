<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ZbabelecController extends AbstractController {
        
    public function zbabelec(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Zbabělci </h1>
            <p>
            Literární druh a žánr: román
            Literární směr: sociálně-kritický
            Slovní zásoba a jazyk: bohatá slovní zásoba, dialogy vystihující názory a výrazy tehdejšího období
            Hlavní postavy: Eda Soukup, bratři Holanovi, Lejna, Gerta a další
            Kompozice: lineární
            Prostor a čas: Praha v 50. letech 20. století
            Význam sdělení (hlavní myšlenky díla): kritika totalitního režimu, úvaha o statečnosti a zbabělosti, sociální a politický komentář k době
            SPOLEČENSKO-HISTORICKÉ POZADÍ: poválečné Československo, komunistický režim
            
            děj:Němečtí vojáci pomalu ustupují zpátky do své vlasti pod útlakem sovětských vojsk, ale v Kostelci, kde žije hlavní hrdina knížky, je zatím klid. Místní lidé tu plánují vlastní revoluční obrat a Danny s kamarády začali začerňovat německé nápisy, aby tak dali najevo svůj odpor vůči Němcům. Zatímco Ireně vyznává lásku (kterou mu dívka neopětuje, protože miluje Zdeňka), náměstím jde fašistická armáda. Danny rozhořčen Ireninou odpovědí odmítne se ukrýt před Němci a navíc jednomu řekne, aby "držel hubu". Z toho důvodu je fašisty "sebrán" s jedním mladíkem k zastřelení. Když jej spatří Přema, odejde do muničního skladu pro pušky a je ochoten ho s kamarády osvobodit z německého zajetí. Tato vypjatá situace nakonec skončí dobře, protože doktor Šabata to s Němci vyjedná, a proto nedojde k žádnému zranění.
            
            Danny se po této události rozhodne přidat k Přemově partě, aby mohl mít automat (tzn. automatickou pušku). O ten však brzo přijde, když zbraně odevzdají domovské sebeobraně, a tak chodí městem strážit bez pušek.
            
            S Bennem a Harýkem brzo Danny "zdrhne" z kasáren. Druhý celý den proleží doma, protože se cítí nemocný. Nadcházejícího dne potká v městečku skupinu anglických vojáků, a tak se jich ujme a ubytuje je u místních obyvatel.
            
            Kostelcem se šíří zpráva, že sovětská vojska se pomalu přibližují, a proto obyvatelé rozvěšují na domech české a ruské vlajky. Ve městě brzo nastane panika a namísto Rusů se objeví fašističtí vojáci. Benno dostává strach a utíká. Danny chce být hrdina, kvůli Ireně, a vrhne se proto do ulic plných Němců. Zablácený s automatickou zbraní doprovodí zraněného Angličana až do sálu, aby mohl překládat. Pak pokračuje vlastní cestou.
            
            Do Kostelce přijíždí sovětská vojska a všude se začne střílet. V pivovaru (který slouží jako provizorní vězení) jsou zatčení němečtí vojáci, od kterých mají místní spoustu zbraní. Danny tu narazí na Přemu, a proto společně běží k němu pro těžký kulomet, kterým pak zneškodní německý tank a uznání se jim tak dostává i od Rusů, i když pod falešnými jmény.
            
            Ráno se Danny vypraví do pivovaru, kde v tu dobu mučí a zabíjejí fašisty. Potkává i Irenu, jež se bojí o Zdeňka, a proto s ní stráví celý den. Druhého dne ji však uvidí až k večeru, když hraje s kapelou, jak tancuje se Zdeňkem.
            
            
            </body>
            </html>'
        );
    }
}
?>