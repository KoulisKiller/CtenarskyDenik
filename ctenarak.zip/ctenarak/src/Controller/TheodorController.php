<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class TheodorController extends AbstractController {
        
    public function theodor(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Pan Theodor Munsdostock</h1>
            <p>
            Literární druh a žánr:
            Není známo
            Literární směr:
            Není známo.
            Slovní záoba a jazyk:
            Není specifikováno.
            Hlavní postavy:
            Není uvedeno.
            Kompozice:
            Není specifikováno.
            Prostor a čas:
            Není specifikováno.
            Význam sdělení (hlavní myšlenky díla):
            Není známo.
            SPOLEČENSKO-HISTORICKÉ POZADÍ:
            Není specifikováno.
            
            děj: Hlavním motivem Fuksových psychologických próz je úzkost člověka ohroženého fašismem a válkou nebo dobou poválečnou. Jeho postavy jsou velmi senzibilní, bezbranní vůči zlu, kterému se sice snaží čelit nebo z něj alespoň uniknout, ale neúspěšně, proto končívají tragicky. Do jejich života vždy zasahuje drsná fatálnost. Neschopnost čelit drsné realitě doby je vede k chorobným psychickým stavům, které Fuks zřejmě i díky svému studiu psychologie dokonale zachycuje. Jejich psychika vede často až k naprosto zrůdnému myšlení a následně i jednání - viz Spalovač mrtvol, který uvěří, že je představitelem čisté rasy a vyvraždí ve jménu ideologie říše svou položidovskou rodinu a dokonce i kočku. Pan Theodor Mundstock se zase těší do koncentračního tábora, neboť se na nepříjemnosti čekající v něm systematicky připravoval a nevidí ani jinou možnou cestu, neboť se pomátl z neustálého čekání na předvolání.</body>
            </body>
            </html>'
        );
    }
}
?>