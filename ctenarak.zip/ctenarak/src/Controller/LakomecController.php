<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class LakomecController extends AbstractController {
        
    public function lakomec(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Lakomec</h1>
            <p>Literární druh a žánr: Divadelní hra, komedie
            Literární směr: Klasicismus
            Slovní zásoba a jazyk: Klasická francouzština, bohatá na ironii a satiru
            Hlavní postavy: Harpagon, Elmire, Cléante, Valère
            Kompozice: Dialogická, vyprávění
            Prostor a čas: 17. století, Francie
            Význam sdělení (hlavní myšlenky díla): Kritika společenských nedostatků, zejména chamtivosti a materialismu
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Francouzský absolutismus<br>
            </p>
            <p>děj:<br>Jedno z vrcholných děl francouzského klasicismu. Lichvář Harpagon, hlavní postava této hořké veršované komedie, se stal synonymem pro lakomce. Ale ani jeho rodina neoplývá skvělými charaktery. Nové vydání slavného Molierova dramatu je doplněno životopisnou poznámkou o autorovi, soupisem jeho díla a krátkou studií o hře nazvanou Harpagon - lakomec a lichvář. V moderním překladu V. Mikeše.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>