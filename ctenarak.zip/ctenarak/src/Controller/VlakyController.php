<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class VlakyController extends AbstractController {
        
    public function vlaky(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Ostře sledované vlaky</h1>
            <p>
            Literární druh a žánr: novela
            Literární směr: český realistický směr
            Slovní zásoba a jazyk: čeština, spisovný jazyk, běžná slovní zásoba
            Hlavní postavy: Milada Horáková, Mikuláš Jonas, Šílený z Hubenýho
            Kompozice: chronologická, skládá se z několika kapitol
            Prostor a čas: Československo, konec druhé světové války a několik let po ní
            Význam sdělení (hlavní myšlenky díla): Odráží tehdejší dobu, kdy bylo několik let po druhé světové válce, a snaží se ukázat některé zvláštnosti a poměry v Československu.
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Studená válka, komunistický režim v Československu
            děj:Miloš Hrma se zprvu pokusí o sebevraždu, protože "zvadne jak lilium" při svém první pokusu o styk s Mášou - svou milou. Je zachráněn zedníkem, který zrovna pracuje opodál (později zjištění, že to byl Bůh). Na nádraží, kde pracuje, se svým vzorem nádražákem Hubičkou systematicky sabotují ostře sledované vlaky (hlavně s municí). Ke konci roku 1945 se rozhodnou vyhodit jeden z vlaků do vzduchu. Miloš se úkolu ujme. Akce se zdaří a vlak vybuchne, ale na Miloše si počíhal voják. Střelil ho puškou do plic a Miloš reflexivně vojáka střelil pistolí do břicha. Oba se pak svalí vedle sebe do příkopu a Miloš vojáka z milosti dorazí výstřelem do hlavy. Pak umírá.</body>
            </body>
            </html>'
        );
    }
}
?>