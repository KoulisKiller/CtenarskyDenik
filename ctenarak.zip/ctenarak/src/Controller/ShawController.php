<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ShawController extends AbstractController {
        
    public function shaw(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>George Bernard Shaw</h1>
            <p>Život autora: Irský dramatik a spisovatel, zakladatel moderního anglického dramatu
            Autorovo další dílo: Manželství, Don Juan v Manhattanu, Židovský pán
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Oscar Wilde, Henrik Ibsen, Anton Chekhov.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>