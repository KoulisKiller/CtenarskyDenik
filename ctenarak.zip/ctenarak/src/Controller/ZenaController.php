<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ZenaController extends AbstractController {
        
    public function zena(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>zkrocení zlé ženy</h1>
            <p> 
            Literární druh a žánr: Drama
           Literární směr: Klasicismus
           Slovní zásoba a jazyk: Archaický anglický jazyk, velká slovní zásoba, bohatá na metaforické a lyrické prvky
           Hlavní postavy: Petruchio, Kate, Baptista Minola, Hortensio, Lucentio
           Kompozice: Linearní, střídání dialogy a monologů
           Prostor a čas: Itálie, středověk
           Význam sdělení (hlavní myšlenky díla): Manželství, genderové role, moc a vliv, láska a oddanost, žert a humor
           SPOLEČENSKO-HISTORICKÉ POZADÍ: Tudorovské období v Anglii
           
           děj:Děj knihy se odehrává v Padově v rodině bohatého kupce Baptisty a dále pak v sídle mladého Petruccia okolo roku 1595.
           
           Kupec Baptisto má dvě dcery - Kateřinu a Blanku. O Blanku by byl veliký zájem, avšak Baptisto se zařekne, že nejdříve provdá Kateřinu. Tu ale nikdo nechce, protože všechny jen uráží. Blančiným nápadníkům nezbude nic jiného než pro Kateřinu najít manžela. Teprve až odvážný Petruccio se uvolí. Do Baptistova domu zatím vnikli v převlečení Blančini uchazeči. Ta už si vybrala. Nakonec Kateřina se svatbou více méně souhlasí, i když se hodně vzteká. Od té doby začne Petruccio konat své předsevzetí - vychovat Kateřinu. Petruccio dělá to, čím byla proslulá ona. Vzteká se, hubuje. Dokonce jí nechá na svém sídle několik dní o hladu. Otevřou se jí oči a pochopí, že musí změnit své chování. Nakonec se na jedné hostině Petruccio s přáteli vsadí, kdo má poslušnější ženu. Kateřina jako jediná na Petrucciův popud přijde. Petruccio je na ni hrdý.
           
           
            </body>
            </html>'
        );
    }
}
?>