<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ScottController extends AbstractController {
        
    public function scott(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Francis Scott Fitzgerald</h1>
            <p>Život autora: americký spisovatel, představitel jazzového věku, napsal mnoho románů a povídek
            Autorovo další dílo: Pán Let, Tři sta dolarů, Ztracený ráj
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Ernest Hemingway, John Steinbeck, F. Scott Fitzgerald, James Joyce, T. S. Eliot, Ezra Pound.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>