<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ModlitbaController extends AbstractController {
        
    public function modlitba(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Motlitba pro Kateřinu Horovitzovu</h1>
            <p>Literární druh a žánr: Drama
            Literární směr: Moderní česká próza
            Slovní zásoba a jazyk: Archaický jazyk, poetický jazyk
            Hlavní postavy: Kateřina Horovitzová, židovský kantor, židovský rabín
            Kompozice: Dramatický monolog
            Prostor a čas: Neurčený, někdy v minulosti
            Význam sdělení (hlavní myšlenky díla): Téma smrti, touha po spáse a vysvobození, křesťansko-židovské vztahy.
            SPOLEČENSKO-HISTORICKÉ POZADÍ: 19. století, židovská komunita v Praze
            děj: Dramaticky vypjatá novela o tragickém osudu židovské dívky, která povýšila pomstu za své soukmenovce na smysl vlastní existence.
            Lustig ve své sugestivní novele zpracovává motiv sadistické léčky, s jejíž pomocí se nacističtí pohlaváři pokusili získat majetek od skupiny zajatých bohatých židovských obchodníků. V druhé rovině novely pak vypráví vlastní příběh hrdinky, dívky, která se na prahu smrti vzepře ponižování své lidské důstojnosti a dokáže v sobě zmobilizovat sílu, schopnou překonat strach i přirozený pud sebezáchovy.
            </p></body>
            </body>
            </html>'
        );
    }
}
?>