<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class JaroslavController extends AbstractController {
        
    public function jaroslav(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Jaroslav Seifert</h1>
            <p>ŽIVOT AUTORA: Jaroslav Seifert se narodil v Praze v roce 1901 a zemřel v roce 1986. Byl český spisovatel, básník a novinář. Získal Nobelovu cenu za literaturu v roce 1984.
            Autorovo další dílo: Mezi okny, Těžko říci, Paměti a prózy.
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Vladislav Vančura, Karel Čapek, Jaroslav Hašek, František Halas.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>