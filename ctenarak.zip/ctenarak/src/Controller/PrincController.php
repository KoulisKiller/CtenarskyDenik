<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class PrincController extends AbstractController {
        
    public function princ(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Malý Princ</h1>
            <p>Literární druh a žánr: Beletrie, próza
            Literární směr: Existencialistický a symbolický
            Slovní zásoba a jazyk: Jazyk je jednoduchý a srozumitelný, slovní zásoba je bohatá na metaforické a symbolické výrazy.
            Hlavní postavy: Malý princ, Střelec, Král, Bažant, Rozumný muž, Poutník, Slona a Liška.
            Kompozice: Kniha se skládá ze vzpomínek hlavního hrdiny, Malého prince, na své cesty a setkání s různými postavami.
            Prostor a čas: Kniha se odehrává na několika planetách a v mezihvězdném prostoru. Časové rozpětí je nejasné.
            Význam sdělení (hlavní myšlenky díla): Kniha hlouběji zkoumá otázky lidské existence, lásky, přátelství a odpovědnosti.
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Byla napsána v období mezi dvěma světovými válkami.<br>
            </p>
            <p>děj:<br>Není pohádka jako pohádka a není princ jako princ. Tenhle je skutečně jen jeden – kouzelná bytost, která přichází na naši Zemi ze vzdálených vesmírných světů. V africké poušti se s Malým princem setkává opuštěný letec, autor našeho příběhu. Zatímco se pokouší opravit havarovaný stroj, povídají si o všeličem. O tajemství podivuhodné pouti Malého prince, o dobru a zlu, o přátelství a kráse, o pravém štěstí, o odpovědnosti za ty, které máme rádi.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>