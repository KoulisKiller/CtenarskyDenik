<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class FarmaController extends AbstractController {
        
    public function farma(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Farma Zvířat</h1>
            <p>Literární druh a žánr: Román, politický satira
            Literární směr: socialistický realizmus
            Slovní zásoba a jazyk: jednoduchý, srozumitelný, s důrazem na výpovědní hodnotu
            Hlavní postavy: Napoleon, Snowball, Boxer, Minksy, Old Major
            Kompozice: chronologická
            Prostor a čas: farmářská země, 20. století
            Význam sdělení (hlavní myšlenky díla): Kritika kapitalistického zřízení a komunistický přístup k řešení společenských problémů
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Vznik knihy se datuje do období studené války a komunistického hnutí v Anglii<br>
            </p>
            <p>děj:<br>:Bilingvní, anglicko-české vydání světoznámého románu. Farmu zvířat, své nejcennější dílo, napsal George Orwell v letech 1943 a 1944, poprvé ale vyšla až v roce 1945, a to po značných peripetiích. Orwell nemohl najít nakladatele: sovětské Rusko se lvím podílem zasloužilo o porážku Německa a britští nakladatelé nepokládali za přijatelné vydat text, jenž je ostrým útokem na Stalinův režim. Kniha vyšla až v době, kdy začínaly být patrné známky nastávající studené války. Z politické bajky a alegorie se brzy po vydání stal bestseller. Důvodů obrovského úspěchu knihy je hned několik: vedle nezpochybnitelných literárních kvalit a estetické působivosti to byla kritika stalinského režimu, ve své době velmi řídká. Navíc realitu tehdejšího Sovětského svazu představila způsobem veskrze komickým a důvěrně známým, takže banalita zla vyvstala v celé své hrozivosti.
            Alegorie Farmy zvířat je zřejmá na první pohled - na velice malém prostoru tu Orwell ve vynikající zkratce zachytil dějiny Sovětského svazu, a to od šíření leninské ideologie (vystavená lebka „prasečího Lenina" Majora jako parodie mauzolea), přes říjnovou revoluci až po střet Stalina s Trockým a následné vyštvání Trockého. V podobě stachanovce Boxera je zachyceno pracovní nadšení, ve stále menších přídělech krmení krize bolševického hospodaření, a celá kniha končí satirou paktu o neutočení, válkou a následným přerodem revolučních prasat v jejich největší nepřátele - lidi.
            Z literárního hlediska je zajímavá volba metafor: zatímco některé jsou poměrně očekávané (psi jako tajní policisté, kůň jako stachanovský dříč, ovce jako nepřemýšlející masa), jiné naopak poměrně překvapí, zejména ta ústřední - neškodní pašíci, jak je známe z pohádek, působí jako vůdci proletariátu, diktátoři a původci všeho zla neotřele, byť to je metafora případná, přinejmenším z hlediska fyziognomie.
            Další velice zajímavou postavou je osel. Orwell ve svých realistických románech nikdy neodolala a vždy v textu vytvořil autoportrét - nejinak tomu je i ve Farmě zvířat, kde lze za autorovo alter ego považovat právě postavu osla Benjamina, trochu cynického, veskrze fatalistického a na první pohled nezúčastněného „intelektuála". Benjamin, „nejstarší a nejmrzutější zvíře na statku", se do dění kolem aktivně zapojí pouze v okamžiku, kdy se zlo bezprostředně dotkne jeho přítele Boxera. S revolucí sice souhlasí, nicméně od samého počátku je mu jasné, že se život většiny zvířat nezlepší. Pozoruhodné je i zachycení proměn revolučních nálad a postupná uzurpace moci ze strany prasat, a vývoj kolektivní paměti, umně manipulované prasaty, kdy se z Kulišova hrdinství postupně stane zbabělost, a nakonec dokonce zrada; revoluční desatero je krok po kroku upravováno a měněno a nakonec je nahrazeno lapidární tezí vyjadřující nadřazenost prasat. Orwellovi se podařilo mimořádně zdařile zachytit bujení totalitní mocenské mašinérie - ta nesílí v důsledku nějakého důkladného naplánování a pevné mechaniky, nýbrž mnohem jednodušeji a povrchněji: často jde o souhrn náhod, přičemž síla prasat spočívá právě v tom, že náhody, vnější okolnosti (spory mezi lidmi) i přirozené skutečnosti (povaha některých zvířat) dokáží oportunisticky využívat ve svůj prospěch.
            Příběh revoluce, jak jej Orwell načrtl ve Farmě zvířat, je tragický. Z hlediska většiny zvířat na farmě k žádné změně nedošlo, pouze se snad nakrátko zlepšila jejich nálada. Dokonce i název se vrátil do své původní podoby, a tak jediná změna se odehrála na postu „pána". Farma zvířat je umělecky pozoruhodnou bajkou a svědectvím o jasnozřivém vhledu do dějin revoluce a naivním chápání jejích ideálů.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>