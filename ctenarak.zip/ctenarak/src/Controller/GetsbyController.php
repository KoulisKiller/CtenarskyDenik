<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class GetsbyController extends AbstractController {
        
    public function getsby(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Velký Getsby</h1>
            <p>
            Literární druh a žánr: Román
            Literární směr: Realismus, Naturalismus
            Slovní zásoba a jazyk: Běžná mluva
            Hlavní postavy: Jay Gatsby, Daisy Buchananová, Nick Carraway
            Kompozice: Chronologická
            Prostor a čas: 20. léta 20. století, Long Island a New York, USA
            Význam sdělení (hlavní myšlenky díla): Osamělost, touha po bohatství a slávě, korupce a pomíjivost amerického snu
            SPOLEČENSKO-HISTORICKÉ POZADÍ: 20. léta 20. století v USA, prosperity a rozkvět výstavby, korupce a nadvláda bohatých
            děj:Příběh se odehrává několik let po první světové válce ve Spojených státech amerických, když se mladý muž Nick Carraway přestěhuje ze západního pobřeží do New Yorku, aby zde mohl obchodovat na burze. Spřátelí se se svým novým sousedem Jayem Gatsbym, jenž - jak zjistí - je velmi proslavený díky večírkům, které každý týden pořádá. Gatsby požádá Nicka o seznámení se svou starou lásku, Daisy, jež je blízce příbuzná s Nickem.
            
            Daisy se ocitá v rozpacích, když Gatsbyho znovu uvidí, jelikož je již několik let vdaná. Uchvátí ji však Gatsbyho obří majetek.
            
            Nick brzy přijde na to, že Daisyno manželství příliš nefunguje a že ji její manžel Tom už nějakou dobu podvádí s ženou jménem Myrtle.
            Gatsby požádá Daisy, aby opustila Toma a zůstala navždy s ním.
            
            Jednoho dne, po hádce mezi Gatsbym a Tomem, odjede však Daisy v Gatsbyho autě domů a nešťastnou náhodou srazí Myrtle. Gatsby ale vezme vinu na sebe.
            Wilson, manžel Myrtle, se chce pomstít, zastřelí Gatsbyho a poté spáchá sebevraždu.
            
            Celá kniha končí Gatsbyho pohřbem, kam se, ačkoliv měl za života Gatsby stovky přátel, nedostaví nikdo kromě Nicka a Gatsbyho otce. Nick znechucený společenskou smetánkou odjíždí zpátky domů na západ.
            
            
            </body>
            </html>'
        );
    }
}
?>