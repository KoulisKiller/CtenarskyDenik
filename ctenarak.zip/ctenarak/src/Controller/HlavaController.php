<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class HlavaController extends AbstractController {
        
    public function hlava(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Hlava XXII</h1>
            <p>Literární druh a žánr: Beletrie, Novela
            Literární směr: Absurdní a existenciální literatura
            Slovní zásoba a jazyk: Jazyk je specifický a srozumitelný pro odborníky na filozofii a psychologii. Slovní zásoba je použita s cílem vyjádřit složité myšlenky a filozofické teze.
            Hlavní postavy: Hlavní postavou je nejmenovaný muž, který je autorem textu.
            Kompozice: Kniha je složena z 22 kapitol, které jsou rozděleny do více částí. Každá kapitola se zabývá jednou specifickou myšlenkou a jednotlivé části se násobně odkazují jedna na druhou.
            Prostor a čas: Prostor a čas nejsou konkrétně definovány.
            Význam sdělení (hlavní myšlenky díla): Kniha je považována za kulturní a literární ikonu a reflektuje na život, smrt a význam existence. Hlavní myšlenkou je otázka po smyslu života a jeho hodnotě.
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Kniha vznikla v době kulturního a společenského rozkvětu a filozofických diskuzí.<br>
            </p>
            <p>děj:<br>První a zároveň nejslavnější a dnes již klasický protiválečný román Josepha Hellera Hlava XXII. Fenomenální úspěch, který mu otevřel cestu k velké spisovatelské kariéře, získal především popisem osudů hlavního hrdiny Yossariana a jeho letka bombardérů útočících na Itálii. Heller vychází ze svých vlastních zkušeností a svou prózou předznamenal to, co v americké kultuře naplno otevřela vietnamská válka o pětadvacet let později.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>