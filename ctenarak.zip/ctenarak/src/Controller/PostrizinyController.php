<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class PostrizinyController extends AbstractController {
        
    public function postriziny(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Postřižiny</h1>
            <p>
            Literární druh a žánr: próza
            Literární směr: realismus, humor
            Slovní zásoba a jazyk: vtipný a někdy absurdní jazyk, často využívá slang a hovorové výrazy
            Hlavní postavy: Míša, hospodský
            Kompozice: záměrně neuchopitelný příběh, vyprávění se střídá mezi hlavní postavou a vedlejšími postavami
            Prostor a čas: Československo v 60. letech 20. století
            Význam sdělení (hlavní myšlenky díla): Hrabal vystihuje komickou stránku každodenního života a vztahy mezi lidmi, ironicky komentuje absurditu a absurdnosti společnosti
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Československo v době normalizace
            
            děj: Vyprávění o krásné mladé manželce správce maloměstského pivovaru a její všemi obdivované hřívě předlouhých vlasů si našlo cestu k srdcím bezpočtu čtenářů i filmových fanoušků. Doslova neodolatelně působí také postava svérázného strýce Pepina. Spisovatel tuto svou knihu obdařil nekonečným proudem neuvěřitelných historek, tedy atributy, jimiž , jsou věrným obrazem samotného autora. Idylická atmosféra ospalého maloměsta je takřka dokonalou kulisou pro drobné výstřednosti i pro - především slovní - eskapády strýce Pepina, jakož i pro poněkud bizarní snahy jeho usedlého bratra, hrdinčina manžela. Koktejl, který autor namíchal z osudů těchto tří protagonistů a okořenil mnoha dalšími drobnými postavami, působí dodnes tak osvěžujícím dojmem, že se člověku ani nechce věřit, že vznikl před několika desítkami let.
            </body>
            </body>
            </html>'
        );
    }
}
?>