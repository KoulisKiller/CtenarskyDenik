<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ValkaController extends AbstractController {
        
    public function valka(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Jak jsem vyhrál válku</h1>
            <p>Literární druh a žánr: Román
            Literární směr: Absurdní humor
            Slovní zásoba a jazyk: Ironický, satirický
            Hlavní postavy: Protagonisté záporných charakterů
            Kompozice: Chronologická, přímé i nepřímé řeči
            Prostor a čas: Fiktivní země v době války
            Význam sdělení (hlavní myšlenky díla): Kritika válečných konfliktů a jejich absurdnosti, karikatura válečných hrdinů a jejich vyprávění
            SPOLEČENSKO-HISTORICKÉ POZADÍ: 2. světová válka<br>
            </p>
            <p>děj:<br>:Nesmrtelný válečný román z roku 1963, v němž válku bere vážně snad jen jeho hlavní protagonista, poručík britské spojenecké armády Ernest Goodbody, si od svého prvního českého vydání získal řadu příznivců i u nás a stal se knihou, kterou lze bez váhání označit za kultovní. Ač svérázný důstojník zůstává na stránkách příběhu naivně přesvědčen o bezpodmínečné oddanosti své jednotky, je stále více zřejmější, že zásady vojenské taktiky se tu spíše než v boji za Krále a Vlast uplatňují při zápolení o zdroje alkoholického či erotického uspokojení. Donkichotský Goodbody se během několikaleté anabáze snaží vrátit válce její důstojnost, ale čtenář záhy pochopí, že jde o absurdní počínání - válka je beznadějně směšnou záležitostí a smích je také to jediné, čím ji lze porazit.
            O kvalitách této satirické prózy svědčí i fakt, že se v roce 1967 stala předlohou pro stejnojmenný britský film s Johnem Lennonem v jedné z ústředních rolí.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>