<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class BouleController extends AbstractController {
        
    public function boule(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Pirre Boulle</h1>
            <p>Život autora: Není znám.
            Autorovo další dílo: Není známo.
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Jean-Paul Sartre, Samuel Beckett, Eugène Ionesco.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>