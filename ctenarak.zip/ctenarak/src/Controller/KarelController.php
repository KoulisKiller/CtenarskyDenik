<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class KarelController extends AbstractController {
        
    public function karel(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Karel Hynek Mácha</h1>
            <p>Život autora: Český básník, jedna z nejvýznamnějších osobností národního obrození
            Autorovo další dílo: Máj, Kytice
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Jan Neruda, Vítězslav Nezval, Josef Čapek.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>