<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class UbozaciController extends AbstractController {
        
    public function ubozaci(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Ubožáci</h1>
            <p>
            Literární druh a žánr: Drama, sociální drama
            Literární směr: Realismus
            Slovní zásoba a jazyk: Francouzština, využití výstižných a realistických popisů
            Hlavní postavy: Jean Valjean, inspector Javert, Fantine, Cosette
            Kompozice: Příběh s přímou a výpovědí
            Prostor a čas: Paříž a okolí v 19. století
            Význam sdělení (hlavní myšlenky díla): Kritika společenských a sociálních poměrů, lidská práva, lidská důstojnost
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Francouzská revoluce, napoleonské období, industriální éra
            děj:Děj se odehrává v letech 1815-1830 ve Francii. Vypráví o bývalém vězni Jeanovi Valjeanovi. Byl 16 let na galejích za to, že ukradl chleba (2 roky) a utíkal (14 let). Po návratu z galejí se chtěl ubytovat, ale i když měl peníze, nechtěl ho nikdo obsloužit jídlem ani noclehem. V noci seděl u nějakého domu a potkala ho žena, která mu poradila, aby šel do domu biskupa. Tento biskup se snažil pomáhat chudým. Dal mu polévku s chlebem a uložil ho ve svém domě. V noci Valjean ukradl stříbrné lžičky a byl polapen. Měl být zatčen, ale biskup se ho zastal. Řekl jim, že mu ty lžičky dal. Valjean je nejprve nechtěl přijmout, ale biskup ho přesvědčil, ať si je vezme a pomůže chudým. V roce 1820 už měl Valjean továrnu na textilie, útulek pro děti a nemocnici pro chudé. Byl zvolen starostou. Ve svém nejlepším období pak potkává svého dozorce z vězení a ten je mu přidělen jako velitel státní policie. Mezitím přichází do továrny žena, Fantina, která má dceru, ale její muž zemřel a ona by ji nedokázala uživit. Dítě dá na starosti jedné hospodské, ta ji nenávidí a z dítěte se stává služka. Fantina umírá a pověřuje Valjeana, aby vyzvedl dceru Cosettku od hospodské.
            Probíhá proces s mužem, který je omylem považován za Valjeana a je souzen za krádež peněz. Valjean se k tomuto soudu dostaví a odhalí zde svou totožnost. Je vězněn. Z vězení uprchne, vyzvedne Cosettku a uprchne s ní do Paříže. Zde se do ní zamiluje chudý student Marius.
            Valjean zachrání Mariovi život na barikádách. Marius si bere Cosettku. Valjean se Mariovi svěří se svou minulostí. Ten ho k vůli tomu zavrhne. Pak se ale dozví, komu vděčí za život a s Cosettkou ho jednou navštíví. Valjean je ale nemocen a umírá.
            
            </body>
            </html>'
        );
    }
}
?>