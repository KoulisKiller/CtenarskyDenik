<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class SuhajController extends AbstractController {
        
    public function suhaj(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Nikola Šuhaj loupežník</h1>
            <p>
            Literární druh a žánr: beletrie, román
            Literární směr: není specifikován
            Slovní zásoba a jazyk: jazyk je běžný, slovní zásoba odpovídá žánru a době vzniku díla
            Hlavní postavy: Nikola Šuhaj
            Kompozice: chronologická
            Prostor a čas: doba vzniku díla, místo není specifikováno
            Význam sdělení (hlavní myšlenky díla): není specifikováno
            SPOLEČENSKO-HISTORICKÉ POZADÍ: doba vzniku díla
            děj: Baladický román, situovaný do Zakarpatska v době těsně po 1. svět. válce, o společenské vzpouře, o přátelství, lásce a zradě. Autor ve své baladě líčí na jedné straně krásu nedotčené přírody, na druhé straně pak bídu a primitivní podmínky v tomto opomíjeném a zanedbaném koutě Evropy. Vypráví o životní pouti podkarpatského zbojníka, mladého, civilizací nedotčeného a impulzivního horala, srostlého s rodnou krajinou. Na zbojnické stezky ho vyhnala bída a nespravedlnost, a on se po čase stává hrdinou svého lidu, jenž bohatým bere a chudým dává. Svou vzpourou podněcuje v ostatních touhu po lepším světě. I když nakonec Nikola hyne zradou svých lidí, žije nadále v jejich paměti, v pověstech a písních.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>