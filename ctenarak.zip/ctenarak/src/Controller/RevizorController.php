<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class RevizorController extends AbstractController {
        
    public function revizor(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Revizor</h1>
            <p>
            Literární druh a žánr: Hra, komedie
            Literární směr: Realismus
            Slovní zásoba a jazyk: Francouzština, využití satirických a ironických prvků
            Hlavní postavy: Švindlérův zástupce, Major, hrabě, hraběnka
            Kompozice: Dialogy a jednání mezi postavami
            Prostor a čas: Nezmiňuje se, může být kdekoli a kdykoli
            Význam sdělení (hlavní myšlenky díla): Kritika moci a korupce ve společnosti
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Francouzská revoluce, napoleonské období
            
            děj:Do malého provinčního městečka pronikne zpráva o tajném příjezdu revizora z Petrohradu. To zcela vyvede z rovnováhy místní úředníky i ostatní činitele, kteří mají špatné svědomí kvůli různým podvodům. Jsou neschopní a berou úplatky. Domnělým revizorem je petrohradský úředníček Ivan Alexandrovič Chlestakov, jenž se v městečku zastavuje na cestě ke svému otci. V hostinci, kde bydlí, nemá čím zaplatit, protože veškeré své peníze prohrál v kartách. Proto mu nevadí, že ho pokládají za revizora. Společně s vypočítavým sluhou Osipem dokonale využije situace. Všichni ho podlézavě obskakují, je všude zván, na jeho počest je pořádána večeře, jsou mu nabízeny peníze, hejtman mu dokonce chce dát ruku své dcery.
            Chlestakov odjíždí ve chvíli, kdy se začíná obávat prozrazení. Občané se dozvídají, že přijíždí skutečný revizor. Konečná scéna ukazuje jejich kamenné tváře. Celý děj se odehrává v rozmezí 24 hodin.
            </body>
            </body>
            </html>'
        );
    }
}
?>