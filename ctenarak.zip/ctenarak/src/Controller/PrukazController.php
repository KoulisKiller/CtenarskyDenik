<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class PrukazController extends AbstractController {
        
    public function prukaz(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Občanský průkaz</h1>
            
Literární druh a žánr: Próza
Literární směr: Nezařazeno
Slovní zásoba a jazyk: Realistický, obyčejný jazyk
Hlavní postavy: Neuvedeno
Kompozice: Neuvedeno
Prostor a čas: Neuvedeno
Význam sdělení (hlavní myšlenky díla): Neuvedeno
SPOLEČENSKO-HISTORICKÉ POZADÍ: Neuvedeno
děj:Kniha charakterizuje život party kamarádů, kteří v patnácti letech dostávají své občanské průkazy - malé červené doklady, jež musí nosit u sebe. A tady nastává první problém. Pár dnů od předání občanského průkazu ho Petr ztratí, přičemž na každém kroku je kontroluje strážník Rusnák.
Další problém nastane, když se Petrova rodina snaží emigrovat do zahraničí a někdo je napráská.

Po užívání si alkoholu a svého dětství přichází na řadu vojna, na kterou nikdo nechce. Kluci včetně Petra se snaží vymyslet způsob, jak se vojně vyhnout. Míťa na úmyslný zápal plic umírá, na vojnu jde nakonec jen Popelka. Později Petr zjistil, že na ně donášel důstojník VB. </body>
            </body>
            </html>'
        );
    }
}
?>