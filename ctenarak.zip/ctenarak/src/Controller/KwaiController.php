<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class KwaiController extends AbstractController {
        
    public function kwai(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Most přes řeku Kwai</h1>
            <p>Literární druh a žánr:

            Roman
            Literární směr:
            
            Realismus
            Slovní zásoba a jazyk:
            
            Prostý a srozumitelný jazyk
            Hlavní postavy:
            
            Pannyai, velitel oddílu povstaleckých jednotek
            Kael, mladý bojovník z oddílu
            Táborový starosta
            Starý Muž, moudrý filozof a průvodce v boji
            Kompozice:
            
            Lineární kompozice, děj postupuje chronologicky
            Prostor a čas:
            
            Vietnamská válka, prostředí bojiště
            Význam sdělení (hlavní myšlenky díla):
            
            Osud a hodnoty mladých bojovníků v konfliktu
            Téma odpovědnosti a statečnosti
            Zápas mezi individuálním přežitím a společenskými hodnotami
            SPOLEČENSKO-HISTORICKÉ POZADÍ:
            
            Vietnamská válka a její důsledky<br>
            </p>
            <p>děj:<br> "Most přes řeku Kwan" je román amerického spisovatele Paula Haggise, který se zabývá tematikou lidských vztahů a otázek etiky. Kniha se odehrává v malém městečku na severu Spojených států a vypráví příběh o šesti postavách, které se střetávají na mostě přes řeku Kwan. Tyto postavy představují různé sociální vrstvy a rasy a jejich osudy se navzájem ovlivňují. Kniha vypráví příběh o lidských vztazích, náboženských a politických rozdílech, a také o touze po štěstí a spravedlnosti.

            Hlavním hrdinou knihy je John River, mladý policista, který trpí vážnou duševní poruchou. Jeho příběh se prolíná s příběhy ostatních postav, jako je svobodná matka, která se snaží udržet svůj rod v chodu, nebo starý farmář, který má po svém boku mladou manželku. Tyto postavy se potkávají na mostě a jejich životy se začnou propojovat v nečekaných situacích. Kniha nakonec nabízí naději a názor na to, že i v těch nejtěžších časech může být nalezena naděje a štěstí.
            
            "Most přes řeku Kwan" je významným dílem světové literatury, které nabízí hluboký pohled na lidskou psychiku a vztahy mezi lidmi. Kniha je plná emocí, napětí a překvapení a nabízí čtenářům silný zážitek, který jim zůstane v paměti.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>