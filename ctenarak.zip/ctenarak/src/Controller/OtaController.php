<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class OtaController extends AbstractController {
        
    public function ota(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Ota Pavel</h1>
            <p>Život autora: Ota Pavel (1930-1973) byl český spisovatel a publicista. V letech 1950-1954 studoval na Filozofické fakultě UK v Praze, kde se věnoval především filozofii a dějepisu. Poté se začal věnovat psaní a publikoval své první články v různých časopisech.
            Autorovo další dílo: Mezi jeho další díla patří například knihy "Smrt krásných srnců" a "Svět bez žen".
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ:
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>