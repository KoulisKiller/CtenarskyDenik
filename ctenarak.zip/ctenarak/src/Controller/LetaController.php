<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class LetaController extends AbstractController {
        
    public function leta(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Báječná léta pod psa</h1>
            <p>Autor: Michal Viewegh <br>

            Literární druh a žánr: román
            Literární směr: postmoderní próza
            Slovní zásoba a jazyk: spisovný jazyk, vtipné dialogy, nadsázka
            Hlavní postavy: Vladimír, Marta, Vladimírova rodina a přátelé
            Kompozice: chronologická
            Prostor a čas: Praha v 80. letech 20. století
            Význam sdělení (hlavní myšlenky díla): kritika tehdejšího společenského systému, vtipné zobrazení vztahů mezi mužem a ženou, ironický pohled na život
            SPOLEČENSKO-HISTORICKÉ POZADÍ: normalizace v Československu
            </p>
            <p>děj:<br>"Báječná léta pod psa" je kniha od Jacka Kerouac, která představuje beatnickou subkulturu 50. let. Kniha sleduje život hlavního hrdiny, Dean Moriarty, a jeho cesty po Spojených státech, kde se setkává s různými lidmi a zažívá různé dobrodružství. "Báječná léta pod psa" je pojednáním o svobodě, individualitě a hledání smyslu života v době, kdy tradiční společenské hodnoty byly otřeseny. Kniha je považována za kultovní dílo beatnického hnutí a stále ovlivňuje uměleckou a kulturní scénu.
            </p>

            </body>
            </html>'
        );
    }
}
?>