<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class TwistController extends AbstractController {
        
    public function twist(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Oliver Twist</h1>
            <p>
            Literární druh a žánr: Roman, sociální roman
            Literární směr: Viktoriánský realismus
            Slovní zásoba a jazyk: Běžná angličtina, využití dialektů a slangů
            Hlavní postavy: Oliver Twist, Fagin, Bill Sykes, Nancy
            Kompozice: Vyprávění z pohledu vševědoucího narrátora
            Prostor a čas: 19. století, Londýn, Anglie
            Význam sdělení (hlavní myšlenky díla): Kritika společenských nedostatků, zejména chudoby a zneužívání dětí v průmyslu
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Industrializace, viktoriánská éra
            děj:Příběh vypráví o mladém chlapci Oliverovi, jemuž po narození zemře matka. Oliver vyrůstá v sirotčinci, kde nikdy nepozná lásku a pochopení. Nedostával moc najíst, a tak když jednou přišel požádat o přidání kaše, vedoucí se rozhodli, že jej dál živit nebudou a dají ho do učení k hrobníkovi Sowerberrymu.
            
            Od něj Oliver utíká do Londýna. Tam se seznámí se skupinou lidí, jíž vede Fagin. Nakonec zjistí, že jde o kapesní zloděje, kteří ho nabádají, aby se k nim přidal.
            
            Olivera se ujme pan Brownlow. Po čase se opět setkává se skupinou zlodějů, ti ho donutí vloupat se do domu. Akce se nezdaří a Oliver je zraněn. Svěřuje se paní domu, že byl ke zločinu přinucen a ta se rozhodne nechat si ho.
            
            Když je Oliverovi 18 let, zjistí, kdo byl jeho otec a že mu zanechal velké dědictví.</body>
            </body>
            </html>'
        );
    }
}
?>