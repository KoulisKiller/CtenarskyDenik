<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class NerudaController extends AbstractController {
        
    public function neruda(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Jan Neruda</h1>
            <p>Život autora: Český básník, prozaik a novinář, představitel národního obrození
            Autorovo další dílo: Povídky malostranské, Kongresový sbor
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Jaroslav Vrchlický, Karel Havlíček Borovský, František Ladislav Čelakovský.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>