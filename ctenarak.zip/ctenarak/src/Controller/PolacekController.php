<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class PolacekController extends AbstractController {
        
    public function polacek(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Karel Poláček</h1>
            <p>Život autora: Karel Poláček (1892-1944) byl český spisovatel, publicista, novinář a politik. Byl autorem mnoha knih pro děti i dospělé.
            Autorovo další dílo: Například "Báječná léta pod psa", "Hříšní lidé města Pražského".
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Jaroslav Hašek, Jiří W. Procházka, Jaroslav Foglar.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>