<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class FuksController extends AbstractController {
        
    public function fuks(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Ladislav Fuks</h1>
            <p>Ladislav Fuks
            Život autora:
            Není k dispozici.
            Autorovo další dílo:
            Není k dispozici.
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ:
            Není specifikováno.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>