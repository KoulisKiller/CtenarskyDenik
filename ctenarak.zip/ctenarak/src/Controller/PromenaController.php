<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class PromenaController extends AbstractController {
        
    public function promena(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Promena</h1>
            <p>
            Literární druh a žánr: Próza, drama
            Literární směr: Naturalismus
            Slovní zásoba a jazyk: Přirozený, výstižný jazyk s bohatou slovní zásobou
            Hlavní postavy: Julie Králová, Vlasta Bukovanská
            Kompozice: Vyprávění se střídají dialogy mezi hlavními postavami
            Prostor a čas: V Čechách v druhé polovině 19. století
            Význam sdělení (hlavní myšlenky díla): Autor kritizuje sociální nerovnosti a nespravedlnosti v tehdejší společnosti. Dále zobrazuje životní situaci žen v tehdejší době a jejich boj o svá práva a nezávislost.
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Druhá polovina 19. století, vznikání a rozvoj feminismu v Čechách
            
            děj:"Když se Řehoř Samsa jednou ráno probudil z nepokojných snů, shledal, že se v posteli proměnil v jakýsi nestvůrný hmyz. Ležel na hřbetě tvrdém jak pancíř, a když trochu nadzvedl hlavu, uviděl své vyklenuté, hnědé břicho rozdělené obloukovitými výztuhami, na jehož vrcholu se sotva ještě držela přikrývka a tak tak že úplně nesklouzla dolů. Jeho četné, vzhledem k ostatnímu objemu žalostně tenké nohy se mu bezmocně komíhaly před očima. " Takto začíná jedna z nejslavnějších povídek literatury 20. století. Klíčové dílo literární tvorby Proměna, vypráví velice živý příběh v němž se ukazuje síla Franze Kafky, a právem patří mezi nejlepší povídkové texty na světě. Ilustrace významného argentinského umělce Luise Scafatiho obdivuhodně vystihují zvláštnosti prostředí a osobnosti této povídky a zvou čtenáře k pozoruhodnému dobrodružství.
            ilustrace Luis Scafati</body>
            </body>
            </html>'
        );
    }
}
?>