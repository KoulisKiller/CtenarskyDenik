<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class SpalovacController extends AbstractController {
        
    public function spalovac(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Spalovač mrtvol</h1>
            <p>
            Literární druh a žánr: Novela
            Literární směr: Pražský surrealismus
            Slovní zásoba a jazyk: Kombinace názorových a poetických výrazů
            Hlavní postavy: Pán Tauchman, Kata Tauchmanová, Šimón Tauchman
            Kompozice: Chronologická se zpětnými odkazy
            Prostor a čas: Praha 20. století
            Význam sdělení (hlavní myšlenky díla): Lidé jsou ochotni zaplatit cenu za své touhy a sny
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Československo po 2. světové válce
            
            děj:Pan Karel Kopfrkingl je normální muž. Má krásnou manželku, dceru a syna. Jediné, co je na něm neobvyklé, je jeho zaměstnání. Pracuje totiž jako spalovač mrtvol v pražském krematoriu. Je zvyklý na zacházení s mrtvými těly, má  rád klid a ticho, je velice zběžný. V tu dobu ovšem začínají přípravy na válku. Každý další den může být rozhodující pro další život celé rodiny. Nechá se přesvědčit svým přítelem Willim Reinkem, že to nejlepší, co může udělat je přidat se s ním k SdP. Brzy je tímto děním tak pohlcen, že ho vlastní žena ani syn Milivoj a dcera Zina nepoznávají. Nechá se svým přítelem a příslušností ve straně přesvědčit o tom, že jeho žena, jejíž matka byla židovka není hodna života a jejich děti jsou nečisté. Rozhodne se svou ženu a děti zabít. Jeho krásná Lakmé se oběsí, syna upálí v krematoriu a prohlásí ho za pohřešovaného a posléze se rozhodne stejně naložit i s dcerou.
            
            </body>
            </html>'
        );
    }
}
?>