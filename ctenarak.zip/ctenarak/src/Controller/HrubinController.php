<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class HrubinController extends AbstractController {
        
    public function hrubin(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>František Hrubín</h1>
            <p>Život autora: František Hrubín (1868-1946) byl český spisovatel, dramatik a básník. Proslul jako jeden z nejvýznamnějších představitelů moderní české prózy a dramatu.
            Autorovo další dílo: Balada pro banditu, Šibeniční román, Vrchlabský hostinský
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Jaroslav Hašek, Otokar Březina, Vítězslav Nezval.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>