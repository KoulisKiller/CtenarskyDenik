<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class PetrController extends AbstractController {
        
    public function petr(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Petr Šabach</h1>
            <p>Petr Šabach je současný český novinář a prozaik proslavený zejména knihou Jak potopit Austrálii, odkud pochází jeho nejznámější povídka Šakalí léta, která byla úspěšně převedena do filmu. Píše novelistickou prózu, tíhne k osobní vypravěčské pozici, autobiografickým motivům a k nostalgickému ladění. Tuto knihu jsem si vybral, protože jsem se u žádné jiné tolik nepobavil a také mě zaujalo její skvělé filmové zpracování. V Hovno hoří je popisován život obyčejných lidí, jejich problémy na poli rodinném, doba, ve které žijí, a hlavně život, kde se neustále střetávají cesty mužů a žen.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>