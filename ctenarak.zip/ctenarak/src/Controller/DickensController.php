<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class DickensController extends AbstractController {
        
    public function dickens(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1> Charles Dickens</h1>
            <p>Život autora: Narodil se v Portsmouthu, významný anglický spisovatel, známý pro své sociální romány
            Autorovo další dílo: David Copperfield, Nikdy nekončící příběh, Vánoční koleda
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: William Thackeray, Elizabeth Gaskell, Charlotte Brontë.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>