<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class HellerController extends AbstractController {
        
    public function heller(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Joseph Heller</h1>
            <p>Život autora: Americký spisovatel, sloužil v námořnictvu během 2. světové války
            Autorovo další dílo: Catch-22, Good as Gold
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Kurt Vonnegut, Thomas Pynchon, Ken Kesey
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>