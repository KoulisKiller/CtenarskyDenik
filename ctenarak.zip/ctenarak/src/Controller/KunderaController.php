<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class KunderaController extends AbstractController {
        
    public function kundera(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Milan Kundera</h1>
            <p>Život autora: narodil se v Praze, exil v Francii, významný představitel českého a světového existencialistického a postmoderního stylu
            Autorovo další dílo: "Nesnesitelná lehkost bytí", "Kniha smíchu a zapomnění"
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Ludvík Vaculík, Ivan Klíma, Václav Havel.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>