<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ElegieController extends AbstractController {
        
    public function elegie(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Tyrolská elegie</h1>
            <p>
            Literární druh a žánr: Lyrika
            Literární směr: Moderna
            Slovní zásoba a jazyk: Jazyk výstižný a přímočarý, využití humoru
            Hlavní postavy: Autor, Tyrolský venkov
            Kompozice: Jednotlivé verše tvoří sérii obrazů Tyrolského venkova
            Prostor a čas: Tyrolsko, 20. století
            Význam sdělení (hlavní myšlenky díla): Vzpomínka na Tyrolsko a jeho krásu, hledání domova a stability, vztah člověka k přírodě
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Pobělohorská éra v českých zemích
            děj:Karel Havlíček Borovský, hlavní hrdina, prostřednictvím satiry podává svůj příběh, kde kritizuje habsburský, hlavně Bachův, absolutismus. Dalo by se říci, že příběh líčí měsíci, který jej celou cestu provázel.
            
            Za jedné noci je nečekaně zastižen ve svém domě rakouskými "četníky", kteří mu oznámí, že bude deportován do Brixenu.
            Borovský se proto loučí se svým domovem a po obléknutí se (kterému je věnována značná část) odchází spolu s policisty. Po své cestě kočárem míjí kostelík a vzpomíná na vzácné pouto k tomuto svatému místu.
            
            Během jízdy se koně poplaší, a proto se dají do rychlého klusu. Policisté reagují zbaběle (zde chtěl autor nejspíše upozornit na celkový charakter veřejné bezpečnosti), tudíž může Karel utéci, ale poddá se raději svému osudu a dojede do italského města. Celý tento příběh vypráví měsíci.
            
            </body>
            </html>'
        );
    }
}
?>