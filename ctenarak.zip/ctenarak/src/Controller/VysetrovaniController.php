<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class VysetrovaniController extends AbstractController {
        
    public function vysetrovani(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Vyšetřování ztráty třídní</h1>
            <p>
            Literární druh a žánr: Beletrie, Detektivka
            Literární směr: Nezařazeno
            Slovní zásoba a jazyk: Prozaický jazyk
            Hlavní postavy: Hlavní vyšetřovatel, podezřelí
            Kompozice: Chronologická
            Prostor a čas: Místo děje není specifikováno, časový údaj není zmíněn
            Význam sdělení (hlavní myšlenky díla): Ztáta třídní se snaží odhalit pachatele kriminality
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Neuvedeno
            
            děj: Vlastní divadelní hra pojednává o snaze donutit žáky sedmé třídy k navrácení třídní knihy, k jejímuž pravděpodobnému zcizení došlo před sedmi lety. V této snaze se během hry postupně vystřídají všechny čtyři účinkující postavy (třídní učitel, ředitel školy, inspektor a zemský školní rada).
            
            </body>
            </html>'
        );
    }
}
?>