<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ErnestController extends AbstractController {
        
    public function ernest(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Ernest Hemingway</h1>
            <p>Život autora: Ernest Hemingway byl americký spisovatel, novinář a bojovník za mír, známý svými romány o válečných zkušenostech a dobrodružství.
            Autorovo další dílo: "Farewell to Arms", "For Whom the Bell Tolls", "The Old Man and the Sea".
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: F. Scott Fitzgerald, John Steinbeck, William Faulkner.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>