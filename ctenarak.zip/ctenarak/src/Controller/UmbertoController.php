<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class UmbertoController extends AbstractController {
        
    public function umberto(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Umberto Eco</h1>
            <p>Život autora: italský spisovatel, filozof, semiotik, žil od 1932 do 2016
            Autorovo další dílo: Fakulta, Návrat do časů dobrých a nevinných, Baudolino, Kdo následuje Nikaragujského muže
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Italo Calvino, Ecoův současník a kolega, Milan Kundera, Gabriel Garcia Marquez.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>