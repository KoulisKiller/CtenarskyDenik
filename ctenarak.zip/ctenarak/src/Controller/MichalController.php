<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class MichalController extends AbstractController {
        
    public function michal(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Michal Viewegh</h1>
            <p>
            Život autora: český spisovatel, narodil se v roce 1962, známý svými humornými romány
            Autorovo další dílo: Mafie v Praze, Báječná léta pod psa 2, Šťastný konec a další
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Daniela Fischerová, Miloš Urban, Jáchym Topol a další.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>