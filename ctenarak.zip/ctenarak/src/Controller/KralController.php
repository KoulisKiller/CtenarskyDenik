<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class KralController extends AbstractController {
        
    public function kral(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Obsluhoval jsem anglického krále.</h1>
            <p>
            Literární druh a žánr: Román
            Literární směr: Absurdní humor a groteska
            Slovní zásoba a jazyk: Někdy absurdní, často humoristický
            Hlavní postavy: Josef Švejk, anglický král a další vojáci a vojenské úředníky
            Kompozice: Chronologická
            Prostor a čas: Rakousko-Uhersko v době první světové války
            Význam sdělení (hlavní myšlenky díla): Satira na vojenskou mašinerii, kritika nesmyslných vojenských zvyklostí a válečného bezútěšného stavu.
            SPOLEČENSKO-HISTORICKÉ POZADÍ: První světová válka, situace v Rakousku-Uhersku
            děj:Tématem Hrabalova slavného románu je životní dráha číšníka, později hoteliéra a nakonec cestáře v době politických zvratů první půle dvacátého století. Od dvacátých do padesátých let prožívá svůj příběh jednoduchý, od mládí snaživý a podnikavý muž, který své úspěchy i neúspěchy připisuje spíše shodám okolností než sobě, ale využívá jich k překonávání svých tělesných a sociálních handicapů. Mnohokrát v životě pocítí, že jím druzí opovrhují pro malý vzrůst, pro sympatie k Němcům, pro jeho češství, proto, že má původ odloženého nemanželského dítěte, i pro osobitou životní filozofii. Nikdy však nezatrpkne, neoplácí nenávistí, nemstí se. Touží po bohatství a uznání ve své profesi, touží po milující ženě - ale dostává se mu jich jen krátce. Není uznán ani jako árijec, ani jako otec, ani jako odbojář, ani jako milionář. I jako samotářský cestář je pro své okolí podivínem. Existenciální téma však autor nepojímá tragicky. Hlavnímu hrdinovi samota nakonec umožní zbavit se touhy po majetku a uznání a dojít ke svérázné, prosté filozofii života, kde se hořkostí a osaměním platí za požitek krásy a svobody.
            </body>
            </body>
            </html>'
        );
    }
}
?>