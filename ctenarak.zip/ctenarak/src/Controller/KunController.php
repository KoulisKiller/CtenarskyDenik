<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class KunController extends AbstractController {
        
    public function kun(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Podkoní a žák</h1>
            <p> 
            Literární druh a žánr: Beletrie
            Literární směr: Realismus
            Slovní zásoba a jazyk: Prostý, jasný a srozumitelný jazyk
            Hlavní postavy: Podkoní a žák
            Kompozice: Lineární, chronologický vývoj děje
            Prostor a čas: Neurčený prostor, časový rámec se nezmiňuje
            Význam sdělení (hlavní myšlenky díla): Autor zobrazuje vztah mezi nadřízeným a podřízeným, kde dochází k osobnímu růstu a změně postojů obou postav. Také se zde diskutuje o otázkách spravedlnosti a nespravedlnosti.
            
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Kniha "Podkoní a žák" byla napsána v době, kdy bylo obyčejné, že existovala silná hierarchie mezi nadřízenými a podřízenými v pracovním prostředí. Tento vztah byl často založen na autoritě a moci.
            
            
            
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Ve stejném období působili jiní autoři, jako například Anton Pavlovič Čechov, Lev Nikolajevič Tolstoj a další, kteří se zabývali tématy jako je vztah mezi nadřízenými a podřízenými, sociální nespravedlnosti a otázky spravedlnosti. Tyto autority se staly významnými představiteli realistického žánru a dodnes představují významný zdroj informací o tehdejší společnosti a jejích problémech.
            děj:Děj se odehrává v neznámé středověké hospodě, kam vchází vypravěč a usedá mezi podkoního a žáka. Ti se začnou hádat, kdo má lepší živobytí, přestože jsou oba velmi chudí. Podkoní se vychloubá, že má trvalé zaměstnání a postel, kde může hlavu složit, zatímco žák spí na zemi. Žák mu odporuje, že prý jí dosyta, ale dozvídáme se, že to není tak docela pravda. Podkoní se mu vysmívá, že tvrdě pracuje ve škole. Žák připomíná podkonímu, že on musí také pracovat a navíc je často bit od pána. Je přesvědčen, že až vystuduje, stane se biskupem a bude se mít dobře a takoví, jako je podkoní, se mu budou klanět. Nakonec se strhne rvačka a vypravěč odchází domů, protože se na to už nemůže dívat. Podle něj jsou na tom oba stejně špatně.
             </body>
            </body>
            </html>'
        );
    }
}
?>