<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class GogolController extends AbstractController {
        
    public function gogol(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Gogol</h1>
            <p>Život autora: Ruský spisovatel, narodil se v Ukrajině, působil v Rusku
            Autorovo další dílo: Mrtvé duše, Zimní zámek
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Aleksandr Sergejevič Puškin, Ivan Sergejevič Turgenev, Fjodor Michajlovič Dostojevskij.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>