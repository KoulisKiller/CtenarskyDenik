<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class MlokController extends AbstractController {
        
    public function mlok(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Válka s mloky</h1>
            <p>
            Literární druh a žánr: sci-fi/fantasy
            Literární směr: avantgardní próza
            Slovní zásoba a jazyk: český jazyk, bohatá slovní zásoba, humoristický tón
            Hlavní postavy: lidská bytost, mloci
            Kompozice: chronologická, s prvky vyprávění z více perspektiv
            Prostor a čas: Praha, časové období není specifikováno
            Význam sdělení (hlavní myšlenky díla): Kritika lidského chování, úvaha o životě a existenci, satira na společnost
            SPOLEČENSKO-HISTORICKÉ POZADÍ: České interwar období
            
            děj:Román se skládá ze tří knih: Andrias Scheuchzeri, Po stupních civilizace a Válka s mloky.
            
            Příběh začíná, když kapitán van Toch (původem Čech) na ostrůvku v jihovýchodní Asii objeví zvláštní druh mloků, kterých se místní obyvatelé bojí a přezdívají jim čerti. Kapitán však zjistí, že tyto mloky lze docela snadno ochočit a naučí je zabíjet žraloky a lovit perly.
            
            Začne mloky cvičit a přesvědčí svého přítele obchodníka Bondyho k založení Salamander Trade, společnosti, jež cvičí mloky a obchoduje s nimi. Mloci se totiž ukážou jako velice inteligentní stvoření, která jsou dokonce schopná se naučit i mluvit a pracovat s jednoduchými nástroji, a tak se brzy dostanou do povědomí světové veřejnosti, která je v touze po penězích z mloků nadšená a začne mloky využívat jako levnou pracovní sílu na stavbu vodních hrází, umělých průlivů apod., ale zároveň také vzdělávat a začleňovat do společnosti.
            
            Obchod se však lidem postupně začne vymykat z rukou, mloci se nebezpečně přemnoží a pobřežní mělčiny už jim k životu přestanou stačit. A tak díky zbraním, které jim dali sami lidé, se mloci vzbouří a začnou po lidech požadovat nová území s tím, že mají pod kontrolou vody celého světa a veškerý odpor je zbytečný. Mloci převezmou vládu nad světem a lidem tak nezbývá nic jiného, než jim dodávat suroviny, potraviny a zbraně.
            
            V závěru románu autor rozmlouvá se svým vnitřním hlasem, jenž ho nabádá, aby nenechal lidskou civilizaci zaniknout. Autor tak přichází s několika alternativními konci. Nakonec dojde k tomu, že se mloci zapletou do národnostních sporů a začnou mezi sebou bojovat, až se vyhubí a svět bude zase jako dřív.
            
            ZÁVĚR:
            
            Román vznikl ve třicátých letech minulého století a reaguje na hrozbu fašismu, který se v té době v Evropě rozmáhal, hrozbu války a možného zániku lidstva. Dalšími Čapkovými díly na toho téma jsou například dramata Bílá nemoc nebo Matka.
            
            Čapek v knize poukazuje na fakt, že mloci, stejně tak jako fašisté, se zprvu vůbec nejeví jako nepřátelé, ani jimi nechtějí být, ale že je třeba nebýt k tomuto problému lhostejný a utnout jejich absurdní požadavky už v zárodku, aby se celá situace neobrátila proti nám (že není řešením Hitlerovi ustupovat a plnit jeho požadavky, že jeho to stejně nezastaví v touze po moci).
            
            Zajímavou postavou románu je pan Povondra, který si celá léta schovával výstřižky z novinových článků o všem, co se týká mloků (v knize je najdeme v části nazvané Po stupních civilizace) a byl hrdý na to, že to byl on, jenž před lety pustil kapitána van Tocha k panu Bondymu a dal tak vzniknout obchodu s mloky. Nicméně poté, co se doslechne, že mloci začínají napadat lidi, cítí o to větší vinu za celou vzniklou situaci.
            
            Ve druhé části knihy s názvem Po stupních civilizace je zajímavá především kapitola, v níž se čtenář dozvídá o novém typu mloka, který je fyzicky i inteligenčně mnohem lépe vyvinutý a který je určený k nadvládě ostatním mlokům, a že se tento mlok vyvinul v Německu. Tím je zde opět naznačena hrozba ze strany fašistického Německa.
            
            
            </body>
            </html>'
        );
    }
}
?>