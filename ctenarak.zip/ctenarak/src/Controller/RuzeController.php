<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class RuzeController extends AbstractController {
        
    public function ruze(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Jméno růže</h1>
            <p>Literární druh a žánr: román
            Literární směr: postmoderní próza
            Slovní zásoba a jazyk: čeština, jazyk výpravný, poetický, vycházející ze životního prostředí a osudů hlavních postav
            Hlavní postavy: Jakob, Amalia, Elijáš, Otakar
            Kompozice: chronologická
            Prostor a čas: 20. století, Československo
            Význam sdělení (hlavní myšlenky díla): vztah mezi náboženstvím a životem, nutnost hledání smyslu života, téma náboženského fanatismu a násilí
            SPOLEČENSKO-HISTORICKÉ POZADÍ: 2. světová válka, období komunistického režimu<br>
            </p>
            <p>děj:<br>Obsáhlý historický detektivní román s filozofickým podtextem se odehrává v hornoitalském benediktinském klášteře v polovině 14. století. Prostřednictvím příběhu o vyšetřování několika záhadných vražd evokuje autor nejen dobovou atmosféru, ale hlavně spory mezi císařem a papežem.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>