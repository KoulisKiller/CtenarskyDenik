<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class KohoutController extends AbstractController {
        
    public function kohout(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Pavel Kohout</h1>
            <p>
            Autor: Pavel Kohout je český spisovatel, dramatik a politický aktivista. Narodil se v roce 1928 v Praze a proslul jako jeden z představitelů českého exilu.

            Život autora: Pavel Kohout se v mládí angažoval v komunistické straně, později však opustil tuto cestu a začal se věnovat psaní a aktivnímu boji za svobodu slova. V sedmdesátých letech emigroval do Rakouska, kde žil až do svého návratu do Česka v devadesátých letech.
            
            Autorovo další dílo: Kromě hry "Občanský průkaz" se Pavel Kohout podílel na napsání mnoha dalších her, jako např. "Komunistický spektákl" nebo "Stručně řečeno". Také napsal řadu esejů a politických článků.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>