<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class EduardController extends AbstractController {
        
    public function eduard(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Eduard Petiška</h1>
            <p>ŽIVOT AUTORA: Eduard Petiška byl významným českým spisovatelem, který se specializoval na řeckou mytologii a dějiny. Studoval na univerzitách v Praze a v Paříži a věnoval se psaní knih a článků o řecké kultuře a filozofii.

            AUTOROVO DALŠÍ DÍLO: Eduard Petiška napsal řadu dalších knih, včetně "Antická mystika" a "Řecké báje". Tyto knihy se také zaměřují na řeckou mytologii a filozofii a staly se významnými zdroji informací o starověkém Řecku.
            
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: V období, kdy byla kniha "Staré řecké báje a pověsti" napsána, existovalo mnoho dalších významných autorů, kteří se zabývali řeckou mytologií a kulturou. Mezi nimi můžeme jmenovat například Edith Hamiltonovou, Roberta Gravese a další. Tyto autority dodnes představují významné zdroje informací o řecké mytologii a filozofii.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>