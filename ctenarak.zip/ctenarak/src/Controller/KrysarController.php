<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class KrysarController extends AbstractController {
        
    public function krysar(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Krysař</h1>
            <p>Literární druh a žánr: Beletrie, krimi a detektivka
            Literární směr: Moderní česká próza
            Slovní zásoba a jazyk: Prozaický jazyk, srozumitelný, běžná slovní zásoba
            Hlavní postavy: Hlavní postavou je krysař, dalšími jsou ženy, které se ocitnou v jeho moci
            Kompozice: Lineární chronologická
            Prostor a čas: Město, současnost
            Význam sdělení (hlavní myšlenky díla): Tématem knihy je život a činy krysaře a jak ovlivňuje své oběti. Dále se kniha zabývá tématem sociálního propadu a kriminality v současném městě.
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Kniha reflektuje sociální a kriminální problémy současnosti.<br>
            </p>
            <p>děj:<br>Útlá knížka, jejímž jádrem je staroněmecká pověst, je vrcholem autorova prozaického díla, jakousi rekapitulací jeho myšlenek a postulátů. Věčným tématem je zde svár reality s ideálem, kterého je ale třeba se nikdy nevzdat.
            Básnická próza inspirovaná romantickým saským motivem ze 13. století o krysaři, který na žádost občanů očistil hanzovní město Hammeln od krys.
             
            Když nedostal slíbenou odměnu, odvedl za trest jeho obyvatelům děti, aby z nich založil kolonii sedmihradských Sasů. Dykův krysař je romantický hrdina s tuláckým srdcem, který odvádí celé město do zkázy jako trest za zklamání v lásce. Propast na hoře Koppel je otevřena a v ní mizí celé hanzovní město, jehož obyvatelé nepochopili hrdinovu snahu o očistu, ani velikost jeho lásky. Nakonec zmizí v propasti i krysař sám jako zosobnění lidské touhy po lásce i jako symbol věčného zklamání.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>