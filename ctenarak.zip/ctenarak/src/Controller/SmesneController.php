<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class SmesneController extends AbstractController {
        
    public function smesne(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Směšné lásky</h1>
            <p>
            Literární druh a žánr: próza
            Literární směr: existencialistická próza
            Slovní zásoba a jazyk: poétický, metaforický
            Hlavní postavy: různé postavy z různých milostných vztahů
            Kompozice: souběžně vyprávěné příběhy o milostných vztazích
            Prostor a čas: Československo v 60. letech 20. století
            Význam sdělení (hlavní myšlenky díla): ironické zobrazení milostných vztahů a jejich absurdnosti, otázky smyslu lásky a sexuality
            SPOLEČENSKO-HISTORICKÉ POZADÍ: normalizace v Československu
            
            děje:Nikdo se nebude smát
            Hlavní postavou a zároveň vypravěčem celého příběhu je mladý muž přednášející na fakultě dějiny umění. Jako recenzent interpretací dějin umění je jednoho dne požádán jistým panem Zátureckým, aby sepsal pozitivní posudek jeho teoretické práce o Mikoláši Alšovi. Doufá totiž, že tento posudek ovlivní jiné lidi, práce bude otisknuta a vynese mu vědecké uznání. Jenže daná práce je nehodná otištění a vypravěč se nechce stát jeho katem. Protože však nemá odvahu mu to říci, neustále před neodbytným panem Zátureckým prchá. Začne překládát přednášky a na jeho hlavu se díky tomu valí problémy s vedením univerzity, které se domnívá, že přednášky ani neproběhly. Pan Záturecký je ovšem stále neoblomný a nadále požaduje o sepsání posudku. Vypravěč se však neodvažuje práci sepsat a stále před ním utíká a skrývá se. Nakonec pana Zátureckého obviní i ze sexuálního obtěžování jeho milenky Kláry a doufá tak, že se ho konečně zbaví. Tyto lži však potom mají velké následky - mladík se sice zbaví otravného vědce, ale příjde jak o svoji Kláru, tak i o místo na fakultě. I přes tento tragický konec má povídka spíše humorný podtext.
            
            "Teprve po chvíli mi došlo, že (navzdory mrazivému tichu, jež mne obklopilo) není můj příběh z rodu tragických, nýbrž spíš komických příběhů." 2
            
            Zlaté jablko věčné touhy
            Hlavními hrdiny příběhu jsou dva přátelé. Jedním z nich je vypravěč celého příběhu, druhým jeho přítel Martin. Martin je v očích vypravěče považován za profesionálního svůdníka žen. Mladík se tedy nechává táhnout za erotickými dobrodružstvími s Martinem a doufá, že mu bude také nějaká žena dopřána. A tak můžeme sledovat jeden z jejich pokusů, o dobrodružství s ženami. Martin má ale manželku, kterou nadevše miluje, a proto celou honitbu za ženami považuje spíše za jakousi hru.
            
            "Tomu říká Martin registráž. Vychází ze svých bohatých zkušeností, které ho dovedly k názoru, že není ani tak obtížné dívku svést, jako je obtížné máme-li v tomto směru vysoké kvantitativní nároky, znát vždy dost dívek, jež jsme dosud nesvedli. Kontaktáž, to je pak už vyšší stupeň činnosti a znamená, že s určitou ženou vejdeme ve styk, seznámíme se s ní, otevřeme si k ní přístup." 3
            
            Falešný autostop
            Mladý pár se vydává na čtrnáctidenní dovolenou do Tater. On je něžný a ohleduplný mladík, ona stydlivá a jemná dívka. Uprostřed cesty se zastaví u čerpací pumpy, aby natankovali benzín. Dívka se mezitím vydá po silnici napřed a když ji mladík v autě dohoní, požádá ho o svezení a dělá, jako by se neznali. Oběma se tato hra zpočátku líbí a chovají se jako někdo úplně jiný. Dívka už není najednou stydlivá, ale vystupuje sebevědomě, mladík se zase s dívkou baví úplně bez zábran. Oba dva začnou na toho druhého žárlit, protože si myslí, že se takto ten druhý chová i normálně. Nakonec dojde k hádce, ale oba dva se stále chovají, jako by se neznali.
            
            "A tak spolu jeli; cizí řidič a cizí stopařka." 4
            
            Mladík později změní jejich trasu a najme pokoj v jiném hotelu. Během večeře se k ní začne chovat oplzle a ona dělá, že jí to nevadí, což ještě více mladíka pobouří. Nakonec se s ní vyspí jako s cizí ženou. Poté leží vedle sebe na posteli a oba ví, že jejich hra zašla až příliš daleko a že toto se nemělo nikdy stát.
            
            Symposion
            Děj se odehrává v noci během služby v nemocnici. Sledujeme rozhovory mezi 5 osobami: doktorem Havlem, sestrou Alžbětou, primářem, doktorkou a medikem Flajšmanem. Během diskuse se rozvíjí filosofické úvahy o lásce, ženách a erotice. Přiopilá sestra Alžběta začne předvádět fiktivní striptýz a poté, co se stane terčem posměchu, dotčeně odchází. Její představení dá nový podnět k debatě. Později najdou nahou a plynem přiotrávenou Alžbětu v pokoji. Naštěstí se jim podaří ji zachránit. Každý si ale o jejím činu myslí něco jiného. Podle doktorky se jednalo o nehodu; podle primáře to byla demonstrace, aby věděli, že Alžběta má krásné tělo; podle Havla se chtěla doopravdy zabít a podle Flajšmana to byl důkaz její čisté lásky k němu. Po této události se opět vracíme k diskusi a tentokrát se vynořují otázky života a smrti v podání ženy.
            
            Ať ustoupí staří mrtví mladým mrtvým
            Starší žena jede jako každý rok navštívit hrob svého manžela. Poté, co se dozví, že hrob byl zrušen, rozmrzele se prochází po neznámém městě. Shodou náhod narazí na bývalého milence, který je ovšem podstatně mladší než ona. Mladík ji pozve k sobě domů, kde nad sklenkou vzpomínají na staré časy. Žena si uvědomuje, že je podstatně starší než muž a vede debatu o stáří. Mladík jí její stáří popírá a tvrdí, že je stále krásná jako kdysi, i když sám je znechucen její proměnou ve starou ženu. I přes toto znechucení se s ní chce pomilovat. Žena odmítá; jednak kvůli svému stáří a jednak kvůli představám, co by si o ní pomyslel její syn. Nakonec ze sebe shazuje tyto pocity a mladíkovi se poddává.
            
            "...a oni jí odpověděli, že mají na hřbitově málo místa a že staří mrtví by měli ustupovat mladým mrtvým." 5
            
            Doktor Havel po dvaceti letech
            V této povídce se nám znovu objevuje postava doktora Havla z povídky Symposion. Tentokrát je Havel o dvacet let starší a za manželku má půvabnou herečku. Sledujeme jeho pobyt v lázních, kam se vydal kvůli problémům se žlučníkem. Až zde si pomalu začíná uvědomovat, že je opravdu starý a že o něj ženy nemají takový zájem jako dříve. V lázních se seznámí s mladým redaktorem místního časopisu, který chce napsat článek o jeho ženě. Postupně se spřátelí a doktor Havel mladíka poučuje o ženách a jejich kráse, s kterou se jako vyhlášený Casanova hojně setkával.
            
            Eduard a Bůh
            Eduard je vesnický učitel, který chodí s katoličkou Alicí. Chce získat její tělo, ona to však odmítá kvůli víře. Proto ze sebe začne dělat horlivého katolíka a doufá, že tak Alici získá. V době komunismu nejsou však katolíci moc vítáni, a tak Eduard začne mít problémy s vedením školy. Aby zabránil vyhození ze školy, začne lichotit ředitelce. Té se Eduard zalíbí a dojde k jejich bližšímu seznámení. Nakonec Eduard dosáhne svého i s Alicí, ale poté zjistí, že to byla velká chyba a že se tím jejich vztah pokazil. Rozloučí se s ní, i když toho v zápětí velmi lituje. Na tomto příběhu je paradoxní, že i když Eduard v Boha nevěří, dále se jím zabývá a přemýšlí o něm.
            
            </body>
            </html>'
        );
    }
}
?>