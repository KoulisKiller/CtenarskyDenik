<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class KlidController extends AbstractController {
        
    public function klid(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Na Západní frontě klid</h1>
            Literární druh a žánr: Román
Literární směr: Realismus
Slovní zásoba a jazyk: Výstižný jazyk, jazyk vojáků
Hlavní postavy: Paul Bäumer, Kemmerich, Katczinsky
Kompozice: Chronologická, vyprávění z pohledu hlavního hrdiny
Prostor a čas: První světová válka, západní fronta
Význam sdělení (hlavní myšlenky díla): Odsouzení válečných konfliktů a jejich ničivého dopadu na jedince
SPOLEČENSKO-HISTORICKÉ POZADÍ: První světová válka, německá společnost
děj: Hlavní hrdina a zároveň vypravěč Pavel Bäumer podlehne spolu s několika dalšími spolužáky (Kropp, Tjaden, Müller, Wolf, Kemmerich aj.) vlasteneckému nadšení svého profesora tělocviku Kantorka a přihlásí se jako dobrovolník na frontu. Počáteční nadšení se ale brzy vytratí. Pavel se svými kamarády nejprve prochází tvrdou průpravou a terorem. Desetitýdenní výcvik pod vedením velitele Himmelstosse je plný šikanování. Po výcviku odjíždí na frontu.
První boje na frontě všem otevřou oči a ukážou válku v pravém světle (plynové útoky, bombardování, budování zákopů, utrpení raněných, smrt přátel, krvavé boje muže proti muži aj.). Vojáci žijí v neustálých obavách o život, trpí hladem, zimou, jsou špinaví, zavšivení. Téměř polovina roty byla již zabita - vojáci, kteří přežijí, dostávají dvojité příděly jídla a tabáku. Stavy vojáků jsou doplňovány velmi mladými chlapci bez výcviku. Pavel postupně ztratí všechny kamarády.
Velkou oporou pro dvacetileté vojáky je velitel roty Stanislav Katczinsky, s nímž se Pavel spřátelil. Po dovolené, ze které se Pavel vrací znechucen (matka umírala na rakovinu, s ostatními lidmi nedokázal nalézt společnou řeč), se dostává zpět na frontu. Uprostřed bitevního pole se najednou ocitne sám zblízka v boji muže proti muži. Smrtelně zraní francouzského vojáka, poté mu ováže ránu a snaží se mu ulehčit umírání. Velkým otřesem je pro Pavla smrt Katczinského. Zraněného se ho snažil s vypětím všech sil odnést z bojiště do bezpečí. Cestou byl však Katczinsky zasažen střepinou a zemřel.
Na podzim 1918 zůstává Pavel poslední naživu ze sedmi spolužáků. Cítí se vnitřně prázdný a velmi unavený. Ke zprávám o příměří je netečný, nevěděl již, zda si vůbec přeje mír. Pavel si je jistý, že se už nedokáže zapojit do normálního života - byl poznamenán roky prožitými na frontě.
Pavel zemřel v září 1918, paradoxně v den, kdy vrchní velitelství podává zprávu, že je na západní frontě klid a neděje se nic nového.</body>
            </body>
            </html>'
        );
    }
}
?>