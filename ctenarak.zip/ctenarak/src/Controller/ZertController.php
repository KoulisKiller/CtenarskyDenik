<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ZertController extends AbstractController {
        
    public function zert(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Žert</h1>
            <p>
            Literární druh a žánr: Novela/smíšený žánr (román, esej, hry, vtipy)
            Literární směr: Absurdní, postmoderní
            Slovní zásoba a jazyk: Pestrý, vtipný, ironický
            Hlavní postavy: Jaroslav, Helena, Marie
            Kompozice: Vícevětový příběh s jednotlivými kapitolami
            Prostor a čas: Praha, 60. léta 20. století
            Význam sdělení (hlavní myšlenky díla): Kritika totalitního režimu a zkoumání lidského vztahů, identity, lásky a věrnosti
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Československo v 60. letech 20. století, normalizace
            
            děj:Knížka Žert vypráví o tom, jak nevinný vtip může mít v totalitním režimu nedozírné následky - ztrátu všeho, co jsme měli.
             Knížka začíná návratem Ludvíka Jána do svého rodného městečka na Moravě, které mu díky dlouhé separaci již nic neříká. Veškeré 
             emoce, láska k rodnému městu a vzpomínky jsou zapomenuty. Teprve později se seznamujeme s jeho charakterem a příkořími, kterými
             musel projít. V celém příběhu se střídají vzpomínky s krutou realitou. Jednoho dne přijde za Ludvíkem Jánem redaktorka z 
             rozhlasové stanice, aby s ním jako s vědeckým pracovníkem nahrála rozhovor. Po té, co se představí jako Helena Zemánková,
             manželka profesora přednášejícího marxismus na univerzitě, dojde mu, že je to manželka jeho bývalého spolužáka a jednoho
             z čelních lidí, kteří zapříčinili jeho utrpení. Vypráví o lásce, kterou měl na univerzitě, o Markétce. Ta byla nedobytná, 
             ale ideologicky velice agilní. Komunistická strana byl pro ní více než jejím vlastním životem. Odmítala chtíč, zajímala se
             jen o ideologii. Jednou Ludvíkovi řekla, že má pro něj překvapení. Hádal, že snad její rodiče odjeli a tak budou moci býti
             společně na chatě, kterou si Ludvík půjčil na týden od svého kamaráda. Tím překvapením však bylo, že Markéta měla jet na
             přednášky o marxismu. On neskrýval své zklamání a ona jej považovala za krutého a sobeckého, bez cítění pro stranu, národ a politické myšlení. Jeho přístup k těmto věcem byl spíše odmítavý. Nebyl žádným hrdinou, který by se proti dění bouřil, ale rozhodně ho nechtěl podporovat, ani se přetvářet. Z přednášek mu napsala pohled, který byl velice politicky laděn. On, aby ukázal svůj nezájem, tak jí jako žert odepsal pohled přibližně následujícího znění: "Optimismus je opiem lidstva, zdravý duch páchne blbostí. Ať žije Trockij...". Tento text jasně vypovídá, jaký byl Ludvíkův pohled na socialismus. Markéta však tuto pohlednici jako žert nebrala a odevzdala ji stranickým kolegům. Ludvík byl prověřován, vyslýchán a podezírán ze spiknutí. Nejdříve byl zbaven funkce ve svazu studentů na univerzitě a posléze hlavně díky svému domnělému kamarádovi Zemánkovi vyloučen z KSČ a univerzity. Zajímavé bylo hlasování o jeho vyloučení, na kterém se všichni shodli a to především z obav, co by mohlo být, pokud by byli proti. Když se Markéty ptal, proč pohled předala, řekla mu, že Strana má právo vědět všechno a že by se to stejně jednou dozvěděla. Slíbila mu, že ho nikdy neopustí, i když jí k tomu Zemánek nabádal. Když ale zjistila, že Ludvíkovy politické názory a aktivita není taková, jakou považovala za adekvátní, tak se s ním rozešla. Protože byl vyloučen z fakulty a byl údajným nepřítelem strany, musel nastoupit na vojnu k "pétépákům". Tam se seznámil s mnoha charakterově rozličnými lidmi, které pojal za své kamarády. Zmiňme například Jindřicha, který neustále posílal manifesty Stalinovi a Trumanovi; Matloch uměl nádherně zpívat a nadávat; nebo takový Čeněk, který studoval na výtvarné škole, kde za své kubistické dílo byl vyloučen. Vedle těchto byl u pétépáků také syn údajného špióna. Ten věřil v ideály komunismu, byl členem Strany, ale jakožto synovi údajného kolaboranta mu nikdo nevěřil. Poslal stížnost, že zde nejsou vychováváni, ale trýzněni. Domníval se, že to celou situaci vylepší. Jeho dopis však neměl předpokládaný úspěch, ba naopak. Byl vyloučen z KSČ, což považoval za osobní prohru. Proto se také otrávil léky. Celý tento děj jen nastiňuje tehdejší skutečnost v pravém světle a utrpení, které museli neloajální lidé během totalitního režimu prožívat. Po kruté a úmorné dvouleté vojně byl přinucen nastoupit do dolů. Ludvík se rozhovoru s redaktorkou takřka neúčastní a počne s ní navazovat kontakt. Klaní se jejímu mladému vzhledu a kráse, ne však z opravdové náklonnosti, ale z důvodu pomsty kamarádovi, který ho kdysi zradil. Od svého evangelického přítele si půjčí byt v rodném městě. Ten ho zrazuje od pomsty, která nic neřeší a jen ze života dělá peklo na Zemi. Ludvík se však nenechá od svého plánu odradit. Sejde se s Helenou, která se mu svěřuje o své lásce k lidovému prostředí. Vypráví, jak se seznámila se svým mužem na manifestaci. Vypráví o jeho životě, především o působení ve folklórním souboru ap. Pod vlivem alkoholu se odeberou do půjčeného bytu, kde se s ní Ludvík vyspí. Takto si Ludvík představoval svoji pomstu na jejím muži a měl ze svého činu radost. Záhy se však dozvídá, že ona se svým manželem již 3 roky nežije. Helena se domnívá, že ji Ludvík miluje stejně jako ona jeho. S bývalým spolužákem Zemánkem se Ludvík o něco později sejde na folklorních slavnostech. Chová se jakoby se nic nestalo, jakoby byli kamarádi. Ludvík na tuto hru přistoupí, i když s ní vnitřně nesouhlasí. Helena už vše o vztahu k Ludvíkovi svému manželovi řekla. On Ludvíkovi jen popřeje mnoho štěstí, protože již má o mnoho mladší přítelkyni. Helena se chce vzdát Jindry, který se o ni již dlouho uchází. Když však zjistí, že ji Ludvík nemiluje, snaží se otrávit prášky, ale místo toho sní omylem jen projímadlo. Jindra se chce Ludvíkovi pomstít, ale to se mu nepovede. Ludvík si nechtěně všechen svůj vztek a nenávist vylije na něm - na nevinném. Ludvík společně se svým kamarádem, který založil folklórní skupinu, hraje na zábavě. Nikdo však jejich hudbě nevěnuje pozornost, což v nich vyvolává negativní pocity. Ludvík jen cítí, že je opět mezi svými, mezi těmi, od nichž byl kdysi násilně vytrhnut. Je zbytečné dodávat, že Milan Kundera bravurně zachytil dění tehdejší doby - neštěstí, ke kterému se člověk může dostat i díky pouhému vtipu. Otázkou je, zda totéž by se mohlo stát v demokratické zemi. Odpověď je ne, proto také nebylo toto dílo tehdejším režimem přijato!
            
            
            </body>
            </html>'
        );
    }
}
?>