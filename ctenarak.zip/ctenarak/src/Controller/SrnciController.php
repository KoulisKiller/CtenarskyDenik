<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class SrnciController extends AbstractController {
        
    public function srnci(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Smrt krásných srnců</h1>
            <p>
            Literární druh a žánr: Prozaické dílo
            Literární směr: Realistický směr v české literatuře
            Slovní zásoba a jazyk: Jazyk se vyznačuje běžnou řečí s využitím některých poetických prvků
            Hlavní postavy: Neznámé
            Kompozice: Lineární
            Prostor a čas: Konkrétní místo a čas není specifikován
            Význam sdělení (hlavní myšlenky díla): Dílo reflektuje život v konkrétním místě a čase a zkoumá lidské vztahy a emoce.
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Není specifikováno
            
            děje:Celou knihu provází nádherný a přímo mistrovský popis přírody, hlavně krajiny kolem křivoklátských lesů a také humor Otova tatínka Lea. Z díla je přímo cítit pokora, láska k přírodě a úcta k člověku.
            
            Kniha obsahuje osm povídek, ve kterých Ota Pavel vzpomíná na šťastné dětství před válkou i hořké časy v době okupace, kdy jako smíšená židovská rodina měli těžký úděl.
            
            Nejdražší ve střední Evropě
            Tatínek pracoval jako obchodní cestující u švédské firmy Elektrolux. Dlouho toužil koupit si vlastní rybník. Maminka zase celá léta toužila jet se vykoupat k moři do Itálie. Tatínek po dlouhé době shánění koupil rybník od doktora Václavíka za deset tisíc korun. Rybník měl být plný ryb. Aby ho doktor přesvědčil, hodil do vody kus housky. Vynořila se velká tlama a houska okamžitě zmizela. Tatínek byl šťastný, jak je to výhodná koupě. Nastal podzim a doba výlovu. Tatínek nechal pozvat všechny známé a přichystal velkou oslavu. Rybáři slavnostně zahájili výlov. Nakonec se ukázalo, že jediným kaprem je ten, který tenkrát tak rychle zhltl housku. Všichni se smáli, jen Popperovi byli nešťastní. Jedině cesta do Itálie zachránila pana doktora Václavíka před boxerským vyřízením celé záležitosti.
            Uplynula řada let. Tatínek byl velmi úspěšným prodávajícím po celých Čechách. Jednou přišel do tatínkovy kanceláře udělat objednávku i doktor Václavík. Tatínek neřekl nic. Doktora naopak pohostil, povyprávěli si spolu, co je nového a nakonec uzavřeli objednávku na speciální ledničku za deset tisíc korun. Doktor zaplatil v hotovosti na místě. Sotva odešel, tatínek dal z jedné rozbité ledničky vyndat vnitřek a upravit ji tak, aby krásně vypadala - jako před lety krajina kolem jeho rybníka. Pak poslal ledničku panu doktorovi do Kročehlav. Ten zavolal montéra, aby lednici zapojil. Ten se zděsil a utekl. Václavík okamžitě telefonoval tatínkovi, že lednice nemá vnitřek. A tatínek mu s klidem odpověděl, že se nedá nic dělat, že je to jako s tím rybníkem. Taky na pohled vypadal moc hezky. Václavík ho ani nežaloval, měl jen smutný večer jako tenkrát Popperovi.
            
            Ve službách Švédska
            Vypráví o a tatínkově obchodním talentu u firmy Elektrolux. V prodeji vysavačů a ledniček se stal mistrem světa. Bylo to hlavně díky paní Irmě, manželce generálního ředitele firmy Elektrolux pana Františka Korálka, do které byl tajně zamilován. Stále si představoval, že se do něj zamiluje i ona. Byl však "chudý" a v očích paní Irmy i společensky nemožný. Na jedné oslavě tatínkových úspěchů se totiž podávalo kuře. Všichni ho jedli způsobně příborem, jen tatínek začal jíst rukama. Tím klesl společensky hodně dolů. Štěstí mu však přálo. Jednou se úplnou náhodou seznámil a spřátelil s malířem Vratislavem Nechlebou. Ten však maloval pouze muže nebo mrtvou Lukrécii. Tatínka Lea měl však ve velké oblibě. Po noci strávené s tatínkem na rybách a ve stanu u řeky Berounky Nechleba slíbil, že paní Irmu namaluje. Tatínek byl nejšťastnější na světě. Irma mu totiž slíbila, že obraz pak spolu oslaví jen oni dva. Okamžitě se vydal pro Irmu a dovezl ji do ateliéru. Nechleba si ji prohlédl a řekl, že takovou paničku malovat nebude. Tatínkovi se alespoň trochu splnil sen. Měl plačící Irmu alespoň chvíli v náručí. Jedinou vzpomínkou na tuto tatínkovu lásku byl obraz Lukrécie, kterou mu kdysi dal malíř Nechleba na památku. Za války ji však u Popperů opilý esesák rozřízl dýkou.
            
            Smrt krásných srnců
            Příběh začíná popisem kraje okolo hradu Křivoklát, kam Ota Pavel jako dítě velmi rád jezdil. Chytal s tatínkem ryby, v chalupě u převozníka Karla Proška pekli chleba. Prošek opatřoval "záhadným způsobem" srnčí maso. Opatřil si totiž psa vlčáka, dal mu jméno Holan. Mezi psem a pánem bylo velmi silné pouto. Věrnějšího psa nebylo. Nad řekou byla zvláštní stráň, kam se chodila pást zvěř. Byla to proto zahrada smrti, která se mohla jmenovat "smrt krásných srnců". Prošek sem chodil s Holanem, vzal hlavu psa do dlaní, nasměroval ho na tečku na stráni a řekl: "Holane, běž!" Pes usmrtil srnu a Prošek ji v batohu odnesl domů. Měli tak maso na celý měsíc. Nikdo na nic nepřišel, ani lesníci, kteří se nemohli dopočítat zvěře a podezírali právě Proška s Holanem. V této době však šťastný život skončil. Jednoho dne i do Luhu přinesl bubeník zprávu o nastoupení moci Adolfa Hitlera a o zřízení Protektorátu. Starší bratři Oty Pavla Hugo a Jiří byli povoláni do koncentračního tábora. Odvážný otec dojel ještě před jejich odjezdem s Davidovou hvězdou v kapse a na rozvrzaném kole pro srnce, aby jím nasytil své syny. To už se bál i kurážný Prošek. Za pytláctví a přechovávání Žida byla totiž smrt. Nemohl tatínkovi pomoci jinak, než že mu slíbil, že mu Holana na lov srnky půjčí. Tatínkovi se to po několika vyčerpávajících dnech skutečně podařilo. Holan jeho povel "Holane, běž!" uposlechl a srnce usmrtil. Srnce mu však málem odnesli dva rybáři. Tatínek je s pomocí Proška zastrašil. Na kole pak srnčí maso vezl zpět za rodinou. Cestou se hrozně bál. Potkal však jednu paní, která mu vyprala zakrvácené šaty a s mužem mu maso pořádně přebalili. Maminka pak chlapcům vařila a pekla srnčí maso, aby nabrali sílu. Možná právě ten srnec zachránil život Jiřímu, který měl po návratu z koncentračního tábora jenom 40 kg. Hlavu toho srnce tenkrát pan Prošek vypreparoval a říkal, že jeho lov byl mnohem dramatičtější než lov zvěře v Africe. Později ji někdo ukradl. Povídka končí smrtí pana Proška krátce po válce, kdy si autor uvědomil, že spolu s ní skončilo i jeho krásné dětství.
            
            Kapři pro wehrmacht
            Odehrává se za války, kdy hned v jejím začátku vzali tatínkovi jeho milovaný rybník. Ten to samozřejmě těžce nesl. Přesto dál chodil své kapry krmit. Tatínek byl také velký vlastenec. Za poslední předválečné peníze koupil originál českou bystu. Za války pracoval tatínek a starší bratři na kladenské šachtě. Rodina tyto časy těžce nesla, zvláště v době vypálení Lidic. Lidice s Buštěhradem od sebe dělil jen kopec. U Popperů byly časté prohlídky domu Němci. Tatínek tehdy přestal k rybníku chodit. Už nevěřil, že bude někdy zase jeho. Pak museli bráškové do koncentráku. Tehdy dvanáctiletý Ota chodil žebrat od vesnice k vesnici, aby mohla rodina posílat synům balíky. Před vánocemi byl povolán i tatínek. Už tehdy se rodině špatně vedlo. Tatínek dva dny před odjezdem prohazoval sníh, když vtom přijelo auto a tři páni v civilu prohlédli barák od shora dolů. Objevili bystu. Tatínek ji před nimi musel hodit na betonový dvorek a na kousky rozbít sekyrou. Druhý sen se dozvěděli, že ten den Němci vystříleli dvě židovské rodiny v okolí. Pak si u Popperů udělali předčasně Štědrý večer. Ota dostal boty s bruslemi. Všichni se přes vážnou situaci tvářili vesele. V noci pak Otu tatínek vzbudil. Byla ukrutná zima, přesto šel s tatínkem k rybníku, vysekali díru do ledu a čekali, až připlují kapři. Pak je rychle chytali a dávali do pytlů. Až do posledního kapra. Ota se strašně bál, že je Němci uvidí a zastřelí. Všude po domě pak byly kádě s rybami. Druhý den šel Ota s maminkou doprovodit tatínka na autobus. Pak začali kapry vyměňovat za jídlo. Byly to nejštědřejší válečné Vánoce. Příští rok za velké slávy chystali Němci slavností výlov. V rybníce však nebyl žádný kapr. Nikdo si to tenkrát nedovedl vysvětlit.
            
            Jak jsme se střetli s Vlky
            Krátká povídka o tom, jak Vlkové dali Otu Pavlovi a jeho tatínkovi na prdel v chytání štik.
            
            Otázka hmyzu vyřešena
            Vypráví o tatínkových poválečných obchodech. Inženýr Jedlička ho požádal o prodej mucholapek BOMBA - CHEMIK. Tatínek si vzpomněl na svůj obchodní talent a plánoval, jak se do roka stane milionářem. Jeho talent opravdu nezmizel, dokonce do svých obchodů úspěšně zapojil i také svého syna Otu. Ale jak rychle uspěl, stejně tak rychle o svou slávu přišel. Mucholapek se sice prodalo hodně, ale teprve, když přišla vedra a měly začít plnit svou funkci, zjistilo se, že jsou k ničemu. Přicházely mu telegramy typu: "Pane Popper. Mouchy nechcípají. Spravujou se!" Tatínek tehdy s obchody skončil, dokonce mamince přiznal, že měla pravdu, že skutečně s mucholapkami díru do světa neudělá. Inženýr Jedlička nakonec všechny mucholapky spálil. Za pár let nato začaly mucholapky vyrábět Holanďané a udělali s nimi díru do světa. Toho už se však Oty tatínek nedočkal.
            
            Prase nebude!
            Později už tatínek neměl ani rybník ani pole u Hřebče. Přijal tehdy nabídku předsedy JZD Vrané Rákosník a šel krmit prasata. Mamince řekl, jestli chce, ať přijde za ním. Dal si za cíl vykrmit nejpěknější prasata v Československu. Maminka za ním skutečně přijela a vzhledem k tomu, že se příliš nelišil od svých "nových dětí", vydrhla nejdříve tatínka od hlavy po paty. Pak spolu rok krmili prasata. Byla to těžká práce. Jako odměnu dostali slíbeno prase. Tatínek už viděl zabíjačku, proto si vykrmoval to nejhezčí pro sebe. Nakonec jim bylo oznámeno - prase nebude. Tatínek se místo zlosti začal smát a objímat se s maminkou. Nakonec z JZD poslali tatínkovi dopis, že po prověrce hospodaření dluží družstvu 530,52 Kčs. Tatínek pak často dopisem mával a ptal se, zda dopis vstoupí do historie.
            
            Králíci s moudrýma očima
            Popperovi prodali chatu a koupili si domeček U Radotína. Byla to jejich poslední štace tady na zemi a byla to štace šťastná. Tatínek si zavedl zvláštní chov šampaňských králíků a maminka úspěšně pěstovala krocany, slepice a prodávala vajíčka. Takhle to táhli skoro deset let. Tatínek se o své králíky staral jak o vlastní děti. Jednou mu kdosi z králíkářského spolku namluvil, že když dá králíky tetovat, může za ně dostat hromadu cen a peněz. Tatínek pozval odborníka a nechat stovku králíků tetovat. Od Nováků z JZD si půjčil bedýnky a chystal se odjet do Karlštejna před komisi rozhodčích. Před odjezdem nařídil mamince vyklidit spíž, dát všude čisté papíry. Pak se s ní rozloučil, jako kdyby jel do války, kterou určitě vyhraje. V Karlštejně mu komise oznámila, že neudělal řádně jakousi manikúru a pedikúru a podobné nesmysly u králíků. Tatínek si s komisí ostře vyměnil názory. Pak seděl a přemýšlel, co by ho mohlo zachránit. Nakonec všichni odešli a on zůstal sám. Otevřel bedýnky, a řekl králíkům: "Kluci běžte!" Jim se od tatínka nechtělo. Ten jim nakonec utekl. Spatřil řeku a šel podle ní až do Radotína. Poprvé šel tak dlouhou cestu bez toho, aby si zpíval. Pak spatřil velkou rybu. Dívali se na sebe. Byla to chytrá ryba, protože ji žádný rybář nikdy nechytil. Přišla se prý na tatínka podívat, jak umírá, protože on za svůj život zabil spoustu ryb. Ráno se tatínek dobelhal k vrátkům. Maminka mu musela pomoci. On se bál podívat do špajzu, protože jestli ho maminka poslechla, tak neměli co jíst. Ale ta ho neposlechla, schválně nechala špajz pootevřený, aby viděl, že jídlo mají. On se na maminku usmál a řekl jí: "Ty můj nejlepší kamaráde!" Pak maminka zavolala sanitku. Tatínek se zdravotníkům vytrhl a běžel domů pro cedulku, kterou si dal jednou namalovat. Pověsil ji na vrátka. Stálo tam: PŘIJDU HNED. A už nikdy nepřišel.
            
            </body>
            </html>'
        );
    }
}
?>