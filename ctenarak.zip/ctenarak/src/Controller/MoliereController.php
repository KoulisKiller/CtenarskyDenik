<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class MoliereController extends AbstractController {
        
    public function moliere(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Moliere</h1>
            <p>Život autora: Narodil se v Paříži, významný francouzský dramatik, herec a režisér, představitel francouzského klasicismu
            Autorovo další dílo: DArtagnanovy dobrodružství, Tajemství, Tartuffe
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Jean Racine, Pierre Corneille, Madeleine de Scudéry.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>