<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class JosefController extends AbstractController {
        
    public function josef(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Josef Škvorecký</h1>
            <p>Život autora: narodil se v Praze v roce 1924, emigroval do Kanady v roce 1968, v roce 1990 se vrátil do Česka, zemřel v roce 2012
            Autorovo další dílo: Taneční hodiny, Špánský tanec, Směšné lásky, Tanec na hlavě
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Ludvík Vaculík, Ivan Klíma, Milan Kundera, Václav Havel a další.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>