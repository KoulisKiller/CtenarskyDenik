<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class RomeoController extends AbstractController {
        
    public function romeo(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Romeo a Julie</h1>
            <p>Literární druh a žánr: Drama, romantická tragédie
            Literární směr: Renesance
            Slovní zásoba a jazyk: Archaický anglický jazyk, bohatá slovní zásoba, básnický jazyk
            Hlavní postavy: Romeo, Julie, Tybalt, Mercutio, Kapuleti, Montekové
            Kompozice: Tragický příběh o lásce, nenávisti a rodinných sporech
            Prostor a čas: Verona, 15. století
            Význam sdělení (hlavní myšlenky díla): Hlavním tématem je láska a nenávist, které se prolínají a ovlivňují osudy hlavních postav. Dále se kniha zabývá tématy jako jsou tradice, rodinné vztahy a konflikty mezi mladými a staršími generacemi.
            
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Drama "Romeo a Julie" bylo napsáno v době renesance, kdy se objevilo mnoho nových nápadů a hodnot. Byl to čas rostoucího humanismu, kdy se začalo zajímat o lidskou bytost jako takovou.
            
            děj:Jak je známo, v italském městě Verona panuje už roky mezi dvěma rody (Montekové a Kapuleti) velký spor.
            Romeo z rodu Monteků se účastní plesu Kapuletů, na kterém se zamiluje do krásné Julie Kapuletové a ona zase do něj. Milenci se nechají oddat otcem Vavřincem.
            Po jejich oddání dochází ke střetu Romea s Tybaltem, který ho k smrti nenávidí a který mu také zabil přítele Merkucia. Proto jej Romeo zabije, za což je za trest vyhoštěn z Verony. Tímto se Julie velmi trápí a ještě více začne smutnit, když se dozví, že její rodina chce, aby si vzala mladého šlechtice Parise. Julie se proto rozhodne jít pro radu k otci Vavřincovi, jenž jí nabídne nápoj, po němž bude vypadat jako mrtvá. Julie souhlasí a nápoj vypije.
            Její rodina ji pohřbí do rodinné hrobky. Když se o tom dozví Romeo, vydá se do Verony a rozhodne se zemřít vedle své milé. Po vypití jedu umírá, ale mezitím se probouzí Julie, která vedle sebe spatří mrtvého Romea. Dýkou si probodne srdce a zemře.
            Jejich rodiny se usmíří až nad jejich společným hrobem, do kterého jsou Romeo a Julie pohřbeni.
            </body>
            </html>'
        );
    }
}
?>