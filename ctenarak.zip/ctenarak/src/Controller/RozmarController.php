<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class RozmarController extends AbstractController {
        
    public function rozmar(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Rozmarné léto</h1>
            <p>
            Literární druh a žánr: Próza
            Literární směr: Realismus
            Slovní zásoba a jazyk: Jazyk je prostý a srozumitelný, slovní zásoba není příliš rozsáhlá.
            Hlavní postavy: Hlavní postavy nejsou specifikovány.
            Kompozice: Příběh se odehrává během letního období.
            Prostor a čas: Místo děje není přesně určeno, časové období není specifikováno.
            Význam sdělení (hlavní myšlenky díla): Kniha reflektuje lidské vztahy, pocity a emoce v letním období.
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Není specifikováno.
            
            děj:Přiznejme si všichni, že náš pohled na klasické Vančurovo dílko je stále neodolatelně okouzlen filmovým zpracováním Jiřího Menzela. Možná právě odtud pramení naše podvědomí trvalé aktuálnosti a nadčasovosti téhle knížky. Rozmarům osudu, počasí, lásky a světa, jimiž jsou ovládány Vančurovy postavy, jsme přece denně vystavováni i my. Je jenom dobře, že stále ještě máme i tyto důkazy nepředvídatelnosti života. A přesně takový svět, náš problematický, ale jediný skutečný svět, obývají již léta rovněž postavičky z kreseb Vladimíra Renčína. Oslovili jsme proto právě jeho a on, ctící dílo svého předchůdce, nám po nemalém váhání posléze vyhověl. Zdá se nám, že příběh tím nově ožil, že jeho protagonisté i ostatní občané lázeňského městečka Krokovy Vary, zachyceni kdysi Vančurovým perem, se dali náhle znovu do pohybu a spějí za svými záležitostmi, tak podobnými těm našim. A to je dobré.
            
            </body>
            </html>'
        );
    }
}
?>