<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class SamotaController extends AbstractController {
        
    public function samota(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Příliš hlučná samota</h1>
            <p>
            Literární druh a žánr: Próza
            Literární směr: Absurdní drama
            Slovní zásoba a jazyk: Básnický, výstižný
            Hlavní postavy: Havran, Šummel, sýkora, vrána
            Kompozice: Kronikářský styl, nesouvislý, symbolický
            Prostor a čas: Neurčený, fantaskní
            Význam sdělení (hlavní myšlenky díla): Lidská osamělost, neúspěšnost v komunikaci, ztráta smyslu života
            SPOLEČENSKO-HISTORICKÉ POZADÍ: 70. léta 20. století, normalizace v Československu
            
            děj:Slavný rytmizovaný monolog literárního hrdiny, hloubavce a pábitele pana Hanti, který si ve sběrně surovin listuje ve starých novinách a knihách.
            Známý román o životních ztroskotancích uprostřed totalitního Československa nabízí poetickou konfrontaci mezi drcením projevů lidského ducha v obludném prostředí sběrny starého papíru a krásou myšlenek, které Hanťa v lisovaných textech nachází. V tomto kontrastu je zdroj autorovy originální poetiky, jež je v této próze zároveň velmi konkrétně svázána s jeho vlastní životní zkušeností. Kniha je doplněna grafickými ukázkami z komiksového zpracování tohoto titulu.
            </body>
            </body>
            </html>'
        );
    }
}
?>