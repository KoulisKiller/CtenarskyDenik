<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class MariaController extends AbstractController {
        
    public function maria(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Erich Maria Remarque</h1>
            <p>Život autora: Německý spisovatel, zážitky z první světové války ovlivnily jeho tvorbu
            Autorovo další dílo: Na západní frontě klid (1929), Když se ztratí iluze (1931), Život jde dál (1932)
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Robert Musil, Franz Kafka, Thomas Mann, Rainer Maria Rilke, Bertolt Brecht.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>