<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class DykController extends AbstractController {
        
    public function dyk(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Viktor Dyk</h1>
            <p>Život autora: Viktor Dyk (1877-1931) byl český spisovatel a publicista. Vynikal jako autor sociálních a vzdělávacích knih, které se zabývaly problémy společnosti a hledáním řešení.
            Autorovo další dílo: Mezi Dykovy další známé knihy patří například "Ztracený člověk" a "Případ Holanďana".
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Mezi dalšími autory tohoto období, kteří se zabývali podobnými tématy, patří například Karel Čapek, Jaroslav Hašek a Alois Jirásek.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>