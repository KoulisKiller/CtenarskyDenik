<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class HrabalController extends AbstractController {
        
    public function hrabal(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Bohumil Hrabal</h1>
            <p>ŽIVOT AUTORA: Narodil se v roce 1890, zemřel v roce 1938 na následky nemoci způsobené nacistickými útoky na Praze<br>
                AUTOROVO DALŠÍ DÍLO: Válka s mloky, Matka, Továrna na absolutno<br>
                DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Jaroslav Hašek, Franz Kafka, Jaroslav Seifert, Max Brod.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>