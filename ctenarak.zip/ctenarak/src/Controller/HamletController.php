<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class HamletController extends AbstractController {
        
    public function hamlet(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Hamlet</h1>
            <p>Literární druh a žánr: Drama
            Literární směr: Klasicismus
            Slovní zásoba a jazyk: Archaický anglický jazyk, velká slovní zásoba, bohatá na metaforické a lyrické prvky
            Hlavní postavy: Hamlet, Claudius, Gertrude, Horacio, Ofélie
            Kompozice: Linearní, střídání dialogy a monologů
            Prostor a čas: Dánsko, středověk
            Význam sdělení (hlavní myšlenky díla): Smrt, sebevražda, žal, zrada, zkorumpovanost, hledání pravdy a odpovědnosti
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Tudorovské období v Anglii<br>
            </p>
            <p>děj:<br>Hamletův přítel Horacio upozorní Hamleta na zvláštní věc. Na hradě Elsinoru se noční stráži zjevuje duch princova otce, který nedávno zemřel. Hamletovi duch sděluje, že jej zavraždil bratr, současný panovník Klaudius. Ten také svedl královnu Gertrudu. Hamlet se rozhodne pro pomstu. Dělá ze sebe blázna. Odmítne lásku Ofélie, dcery prvního královského ministra Polonia. Hamletovi bývalí přátelé jsou Klaudiovými špehy. Hamlet se snaží usvědčit vraha. Využije návštěvy herecké společnosti a prosí herce, aby zahráli hru o kralovraždě. Svědomím krále hra velice otřásla. Hamlet však nedokáže zabít krále, ale vraždí Polonia, který naslouchal za závěsem jeho rozhovoru s královnou. Klaudius chce Hamleta odstranit a posílá ho do Anglie. Místo něj jsou popraveni jeho přátelé a on utíká zpátky. Ofélie z nešťastné lásky zešílela a utopila se. Její bratr Laert se vrátil z Paříže, aby pomstil smrt svého otce. Utkává se v souboji s Hamletem, který je smrtelně zraněn. Zabije krále, královna Gertruda náhodou vypije pohár s jedem určeným pro Hamleta. Hamlet nakonec zabrání Horaciovi k sebevraždě, aby vyprávěl jeho příběh. Hamlet je pohřben s vojenskými poctami.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>