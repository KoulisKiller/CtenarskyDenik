<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class KafkaController extends AbstractController {
        
    public function kafka(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Franz Kafka</h1>
            <p>Život autora: Franz Kafka byl německý spisovatel židovského původu, který se narodil v Praze v roce 1883 a zemřel v roce 1924 ve věku 40 let. Byl považován za jednoho z nejvýznamnějších autorů 20. století a jeho díla jsou často interpretována jako symbol moderního světa a jeho problémů.
            Autorovo další dílo: Kromě "Hlavy XXII" je Franz Kafka známý také díly jako "Proces", "Zámek" a "Amerika".
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Dalšími autory, kteří v této době působili, jsou například James Joyce, Marcel Proust, Thomas Mann a D. H. Lawrence.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>