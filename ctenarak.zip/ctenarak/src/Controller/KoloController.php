<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class KoloController extends AbstractController {
        
    public function kolo(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Vyhodme ho z kola ven</h1>
            <p>
            Literární druh a žánr: Beletrie
            Literární směr: Neznámý
            Slovní zásoba a jazyk: Neznámý
            Hlavní postavy: Neznámé
            Kompozice: Neznámá
            Prostor a čas: Neznámý
            Význam sdělení (hlavní myšlenky díla): Neznámý
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Neznámé
            
             děj: Již klasický román o vzpouře jednotlivce proti mašinérii společenského systému. Kniha byla v roce 1975 zfilmována Milošem Formanem pod názvem Přelet nad kukaččím hnízdem. Román je o dělníkovi jménem Randle McMurphy, který se rozhodne předstírat šílenství, aby se dostal z pracovní farmy a aby ho převezli do státního špitálu pro duševně choré. Soudí, že život tam bude příjemnější...
            
            </body>
            </html>'
        );
    }
}
?>