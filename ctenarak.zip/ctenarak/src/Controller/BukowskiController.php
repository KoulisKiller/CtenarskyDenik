<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class BukowskiController extends AbstractController {
        
    public function bukowski(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Charles Bukowski</h1>
            <p>
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>