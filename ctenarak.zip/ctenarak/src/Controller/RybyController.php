<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class RybyController extends AbstractController {
        
    public function ryby(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Jak jsem potkal ryby</h1>
            <p>
            </p>
            <p>
            Literární druh a žánr: próza
            Literární směr:
            Slovní zásoba a jazyk:
            Hlavní postavy:
            Kompozice:
            Prostor a čas:
            Význam sdělení (hlavní myšlenky díla):
            SPOLEČENSKO-HISTORICKÉ POZADÍ:
            děj: V útlém svazku nazvaném Jak jsem potkal ryby (1974) Ota Pavel vědomě navázal na úspěšnou sbírku Smrt krásných srnců (1972). Opustil definitivně svět sportovců a sportu a vrátil se opět do krajin svého dětství a mládí na Buštěhrad, na Berounku, k řekám, potokům a mořím... Hrdiny jeho povídek jsou opět členové rodiny v čele s "povedeným tatínkem", bratry Jirkou a Hugem, ale prim tu hraje příroda, ryby především ... A hlavně pokora a úcta k člověku. Celek mistrovského literárního díla je návratem k pramenům "vody živé" - a čtenáři odtud mohou spolehlivě čerpat energii a sílu k životu.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>