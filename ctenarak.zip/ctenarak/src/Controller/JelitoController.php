<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class JelitoController extends AbstractController {
        
    public function jelito(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Šunkový nářez</h1>
            <p>
            autobiografický román z roku 1982
            v jiném překladu též jako Jelito (2016, Argo, přeložil Bob Hýsek)
            Vzpomínky na dětství a příběhy ze složitého období dospívání Henry Chinaskiho, autorova alter ega.
            Bukowski nechává čtenáři nahlédnout do nitra člověka, jenž si je vědom toho, že není zcela duševně zdráv, že má násilnické sklony, a proto hledá místo, kde by se mohl skrýt. Jako červená nit se textem táhne odpor k otci, který přispívá k celkovému pocitu odcizení.
            Na autorovy poměry je kniha poměrně málo vulgární.
            
            BIBLIOGRAFICKÉ ÚDAJE:
            
            Vydalo nakladatelství Pragma v Praze roku 1995. Z anglického originálu Ham on Rye přeložila Ivana Machová. Počet stran: 228. ISBN: 80-85213-73-7.
            
            HLAVNÍ POSTAVY A JEJICH CHARAKTERISTIKA:
            
            Henry Chinaski - odtažitý, introvertní, nekomunikativní, cynický, vyrovnaný, inteligentní, nadaný, utopený v lihu a nikotinu
            Henryho otec - panovačný, agresivní, násilný, nekompromisní, pokrytecký, nesoucitný
            
            DĚJ:
            
            Kdyby si Henry mohl vybrat jakoukoli jinou dobu a místo, kde se narodit, než USA v době ekonomické krize ve dvacátých a třicátých letech minulého století, bral by cokoli. Už jako malý byl terčem šikany a mlácení otcem bylo na denní bázi. Jeho otec později přišel o práci stejně tak, jako o ní přišla celá čtvrť, a tak každé ráno dělal, že do ní jezdí. Ve skutečnosti se většinou jezdil jenom opíjet. Také zakazoval Henrymu hrát si s ostatními dětmi, protože jsou z chudých rodin, což by nabourávalo čest jeho rodu. Henry tedy tajně chodil hrát po škole baseball s ostatními. Uměl velice dobře házet i chytat, a tak si našel starší kamarády. To mu však dlouho nevydrželo a měnil je jako ponožky. Takhle žil několik let, dokud se z něj nestal jenom Hank.
            
            Hank byl odlišný od starého Henryho. Už v sobě neskrýval zlost a empatie v něm zbyla sotva hrstka. Už nebyl obětí, teď byl predátorem.
            
            Vzhledem k jeho pubertálnímu období by bylo akné běžnou záležitostí, ale to nebylo jeho případem. Henryho akné bylo jiné, bylo všude. Bylo dokonce tak odporné a nekontrolovatelné, že na něj nepomáhaly žádné mastičky ani jiné přípravky, musel chodit na laserovou terapii. A protože vaše povaha a inteligence je to poslední, co zajímá lidi v tomhle věku, byl Hank skoro pořád sám. Vlastně byl sám radši, než se zahazovat s ostatními - podle něj - stupidními vrstevníky. Radši se chodil se svým kamarádem Plešounem každé odpoledne opíjet pivem a kouřit cigarety. Večer přišel domů, kde schytal všechnu zlost, co jeho otec za den nasbíral a šel spát. Takhle žil každý den.
            
            Když Hank dodělal střední školu, nevěděl, co chce vlastně dělat. Sehnat práci bylo takřka nemožné, a tak mu nezbývalo nic jiného než studovat. Vždycky měl rád literaturu a psal vlastní povídky. Promítal do nich zlosti života, o kterých nikdo nemluvil.
            Ale jednoho dne, když je jeho otec našel, vyházel mu z okna všechny věci a poslal jej pryč. Hank byl vlastně rád. Matka mu dala nějaké peníze a on si našel malý byt. Pořád chodil do školy, teoreticky vzato, protože tam byl přítomný možná tak jenom fyzicky. Občas šli o přestávkách ostatní studenti hrát americký fotbal nebo baseball. Pokaždé, když se Hank přidal, jeho tým zvítězil a z toho druhého odešel někdo se zlomeninou.
            
            Postupně do školy přestal chodit úplně. V té době se Hitler dostával k moci a druhá světová válka šla do tuhého. Všichni jeho kamarádi, jestli se jim tak dalo říkat, protože s Hankem vlastně jenom chodili pít, narukovali na vojnu. Hank ne. Našel si práci jako skladník a za těch málo peněz, co vydělal, si kupoval alkohol, zaplatil nájem a jen tak žil. Každý večer se upil ke spánku a vstával pozdě. Neviděl žádný smysl v tom žít, a tak jenom proplouval jako prostý poustevník...
            
            MYŠLENKA:
            
            Na postupně umírající naději v normální život Hanka můžeme vidět, jak na něj mělo prostředí a doba ve které vyrůstal obrovský vliv. Jeho cynickou nenávist ke všem způsobil jeho otec, jenž se ho snažil vychovat jako něco víc, ač sám byl ničím. Postupný vztek a nenávist, kterou si na něm vybíjel, jej dovedla k nechuti ke všemu a jeho násilí často předával dál. Ale i tak se Hank nakonec rozhodl to utnout. Radši zemře jako ubohá troska než jako troska, co na svět přinese další trosku, kterou budou v nejlepším případě všichni jenom nenávidět.
            </body>
            </html>'
        );
    }
}
?>