<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class SvejkController extends AbstractController {
        
    public function svejk(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Osudy dobrého vojáka Švejka za války</h1>
            <p>
            Literární druh a žánr: Epika (román)
            Literární směr: Realistická próza, humoristický
            Slovní zásoba a jazyk: Český jazyk, řeč vojáků, humor, nadsázka, slang
            Hlavní postavy: Josef Švejk, major Pavel Kašpar
            Kompozice: Chronologická, postavy se vracejí zpět do minulosti
            Prostor a čas: Československo, 1. světová válka
            Význam sdělení (hlavní myšlenky díla): Kritika vojenského a politického systému, ironie, absurdita a bezmocnost běžného člověka v konfliktu
            SPOLEČENSKO-HISTORICKÉ POZADÍ: 1. světová válka, počátky československého státu, politické situace v Československu
            
            
            JAZYKOVÝ PLÁN:
            
            Kniha je protkána různými útvary jazyka, počínaje od německé češtiny, konče až - troufl bych si říci - argotem. Občas i samy postavy mění jazyk, kterým mluví. Hlavní postava, Švejk, mluví obecnou češtinou.
            
            KOMPOZIČNÍ PLÁN:
            
            Děj je uspořádán chronologicky, jak je zvykem u starších děl.
            
            TEMATICKÝ PLÁN:
            
            Celkové téma: život Švejka
            Hlavní téma: zkostnatělá monarchie (tajní, kam se podíváš)
            Vedlejší témata: postava npr. Lukáše
            
            HLAVNÍ POSTAVY:
            
            Švejk - postavička buď naprosto blbá, nebo naprosto geniální
            npr. Lukáš - chce se zbavit Švejka kvůli jeho blbosti
            
            děj:Celé dílo začíná legendární větou "Tak nám zabili Ferdinanda!", kterou pronese Švejkova bytná. Švejk se pak v pravidelně navštěvované hospodě dozví, že začala válka. Vyjeví tedy svůj názor na atentát, který je velmi rozporuplný a za který ho odvedou, protože ho slyšel přisednuvší tajný policista. Z policejní stanice ho ovšem pro jeho imbecilitu pošlou do blázince, kde se mu líbí, protože je o něj dobře postaráno.
            Brzy ho však vyhodí. Cestou z ústavu ho znovu chytí a vyšetřují, ale nakonec se dostane domů. Když válka vypukne, vyráží Švejk na vojnu. Ale v té době má silné revma a nemůže chodit, tak ho jeho bytná odveze na odvod na invalidním vozíku. Jen co se dostane před lékařskou kontrolu, prohlásí o něm, že je simulant a pošlou ho do vojenské nemocnice, kde podstoupí důkladnou pětistupňovou léčbu: klystýr, vyplachování žaludku, lízání chininu, atp. Vzhledem k jeho chování ho ovšem pošlou na garnizónu, což je taková vojenská věznice. V neděli na mši si ho díky jeho pláči při kázání vyhlídne polní kurát, který ho přijme za osobního sluhu. Jenomže nemine ani měsíc a Švejk se dostává do rukou npr. Lukáše, který ho nad polním kurátem vyhrál v kartách. S ním díky malému incidentu s generálovým psíkem odjede zformovat maršbatalión.
            Ovšem to by nebyl Švejk, kdyby se něco nepovedlo. Švejk omylem vystoupí dřív a poté se snaží dostat nějak pěšky do Českých Budějovic, ovšem vždycky nějak netrefí směr. Chvíli je také držen na vesnické stanici kvůli podezření z ruské špionáže. Nakonec se ale stejně dostane do Budějovic, kde se setká se "svým" Lukášem, jenž z něho pomalu spáchá sebevraždu. Nicméně se oba dostanou do vlaku na frontu, čímž příběh končí.</body>
            </body>
            </html>'
        );
    }
}
?>