<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class JinController extends AbstractController {
        
    public function jin(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Ha Jin</h1>
            <p>Život autora:

            Ha Jin se narodil v Číně a v 90. letech emigroval do Spojených států, kde se stal profesorem literatury a kreativního psaní.
            Autorovo další dílo:
            
            "Waiting"
            "War Trash"
            "A Free Life"
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ:
            
            Maxine Hong Kingston
            Viet Thanh Nguyen
            Chang-Rae Lee.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>