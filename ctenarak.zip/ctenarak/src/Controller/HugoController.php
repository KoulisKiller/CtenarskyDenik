<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class HugoController extends AbstractController {
        
    public function hugo(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Victor Hugo</h1>
            <p>Život autora: Francouzský spisovatel a básník, jedna z nejvýznamnějších osobností 19. století
            Autorovo další dílo: Notre-Dame de Paříž, Quasimodo
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Alexandre Dumas, Stendhal, Honoré de Balzac.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>