<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class KrysaController extends AbstractController {
        
    public function krysa(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Král Krysa</h1>
            <p>Literární druh a žánr: Drama
            Literární směr: Absurdní drama
            Slovní zásoba a jazyk: Jazyk hry je poetický, používají se hovorové fráze a nadsázka.
            Hlavní postavy: Král Krysa, Královna, Měšťan, Královský úředník, Šašek
            Kompozice: Drama se skládá ze čtyř aktů.
            Prostor a čas: Prostor hry není specifikován. Čas hry je nespecifikovaný.
            Význam sdělení (hlavní myšlenky díla): Hra Král krysa je absurdním komentářem na společenské záležitosti a kritikuje instituce a systémy, které považují za nereálné a nefunkční.
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Hra vznikla v 60. letech 20. století, kdy došlo k období sociálních a politických změn.<br>
            </p>
            <p>děj:<br>Na východním cípu ostrova Singapuru, v zajateckém táboře Čangi, jsou vězněni spojenečtí vojáci. Krutí japonští dozorci, nedostatek jídla, malárie, cholera i absence zpráv z domova mají za následek, že se z britských a amerických zajatců stávají apatické „chodící mrtvoly". Pouze jediný z nich se nedá připravit o svou vnitřní svobodu - poučen zákony džungle vládne táboru jako Král. Jeho neuvěřitelná vitalita a bezohledná podnikavost se nedají zarazit ani ostnatými dráty, ani nenávistí vlastních spoluvězňů. Protihráčem tohoto sporného hrdiny se v táboře stává anglický pilot Petr Marlowe, potomek staré britské aristokracie. A přestože životní hodnoty obou mužů nemohou být vzdálenější, společně se postaví úsilí svých věznitelů definitivně zlomit důstojnost zajatců... .
            Clavellův slavný román Král Krysa se stal nejen předlohou úspěšného filmu z roku 1965, ale též inspirací neméně populárních divadelních adaptací.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>