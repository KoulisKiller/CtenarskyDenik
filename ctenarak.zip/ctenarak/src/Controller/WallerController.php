<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class WallerController extends AbstractController {
        
    public function waller(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Robert James Waller</h1>
            <p>Život autora: Robert James Waller (*1939) je americký spisovatel, který se proslavil zejména díky svému románu "The Bridges of Madison County" (Mosty v okrese Madison).
            Autorovo další dílo: Mosty v okrese Madison, Dakota, Širá múza
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Nicholas Sparks, Barbara Kingsolver, Thomas Kinkade.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>