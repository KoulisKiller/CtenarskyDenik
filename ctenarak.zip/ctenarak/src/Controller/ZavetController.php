<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ZavetController extends AbstractController {
        
    public function zavet(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Závěť</h1>
            <p>Literární druh a žánr: Beletrie
            Literární směr: Realismus
            Slovní zásoba a jazyk: Prostý, srozumitelný jazyk
            Hlavní postavy: Francois Villion
            Kompozice: Autobiografický, lineární vývoj děje
            Prostor a čas: Francie, druhá polovina 19. století
            Význam sdělení (hlavní myšlenky díla): Kniha zobrazuje život autora v době, kdy žil ve Francie a jeho zážitky s náboženskými, politickými a sociálními otázkami tehdejší společnosti. Dále se zabývá otázkou spravedlnosti a nespravedlnosti.
            
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Kniha "Závěť" byla napsána v době, kdy ve Francii probíhaly politické a společenské změny. Byla to doba, kdy se stala významnou otázka náboženského a politického pluralismu a bojů za svobodu a rovnost.
            děj: Stěžejní dílo klasika francouzské literatury obsahuje 172 osmiveršových strof proložených baladami.
            il. Luboš Drtina   
            <br>
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>