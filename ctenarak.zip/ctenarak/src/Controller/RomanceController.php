<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class RomanceController extends AbstractController {
        
    public function romance(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Balady a Romance</h1>
            <p>Autor: Jan Neruda <br>

            Literární druh a žánr: Lyrika
Literární směr: Realismus
Slovní zásoba a jazyk: Výstižný jazyk, využití lidového slova
Hlavní postavy: Autor, jeho blízcí, vzpomínky na dětství
Kompozice: Sbírka veršů s tematikou vzpomínek, lásky, smutku a radosti
Prostor a čas: Praha, 19. století
Význam sdělení (hlavní myšlenky díla): Hledání identity, vzpomínky na dětství a vztahy, reflektování životních zkušeností
SPOLEČENSKO-HISTORICKÉ POZADÍ: Národní obrození v českých zemích
            </p>
            <p>děj:<br>"Balady a romance" je sbírka poezie od ruského básníka Aleksandra Bloka. Sbírka, která vyšla poprvé v roce 1916, obsahuje verše plné lyrických a filozofických reflexí. Ty se týkají témat jako je láska, smrt, vzpomínky a hledání vlastní identity. "Balady a romance" jsou považovány za jedno z nejdůležitějších děl ruského simbolismu a jsou ceněny pro svou krásu a hloubku. Tyto básně stále ovlivňují současnou ruskou literaturu a uměleckou scénu.</p>

            </body>
            </html>'
        );
    }
}
?>