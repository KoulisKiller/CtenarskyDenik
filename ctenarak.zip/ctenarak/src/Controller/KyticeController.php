<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class KyticeController extends AbstractController {
        
    public function kytice(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Kytice</h1>
            <p>Literární druh a žánr: Sbírka básní
            Literární směr: Romantismus
            Slovní zásoba a jazyk: Lyrický jazyk, využití metafor a příměr
            Hlavní postavy: Různé, většinou nespecifikované
            Kompozice: Sbírka básní s různými náměty
            Prostor a čas: Symbolický, někdy i konkrétní místa v Čechách
            Význam sdělení (hlavní myšlenky díla): Láska, smrt, příroda, národní cítění
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Období romantismu v české literatuře<br>
            </p>
            <p>děj:<br>Snad nejoblíbenější naše básnická sbírka 19. století. Dvanáct vynikajících balad uvedl K. J. Erben stejnojmennou vstupní básní. Mistr umělecké zkratky dokázal ve třech prostých slokách zachytit báji vykládající původ slova mateřídouška. Ve zbývajících třech strofách vyjádřil obrazně svůj názor na dávný, až pohanský původ bájí, naznačil i básnický záměr díla a jeho na svou dobu odvážné věnování slovanským vlastencům. Básník poznal důvěrně české písně i pohádky, a proto toužil doplnit Čelakovského „Ohlasy" promyšleným výběrem lidových námětů epických.
            Sbírka zahrnula hlavní druhy lidové epiky. Nejpočetnější skupinu tvoří báje. Ty nejvíce obrážejí názor lidu na přírodu, v níž se člověk potýká s působením tajemných sil a bytostí (Polednice, Vodník, Vrba, Lilie, Holoubek, Svatební košile). Pro naše předky nebylo hranic mezi živým a neživým světem. A z pohanských mýtů přechází tato představa i do zlidovělé tradice křesťanské. Místní pověsti má za základ nejstarší balada Poklad s námětem Velkého pátku, kdy se odkrývají poklady. Pohádka, a to od Boženy Němcové, byla podkladem Zlatého kolovratu. Legenda barokně romantického ladění je základem Záhořova lože. A hojná jsou právě v naší těžce zkoušené zemi proroctví (Libušino, Sibyllino, slepého mládence aj. ), úryvky z nichž tvoří závěrečnou, vlastenecky povzbudivou, ale i kritickou báseň Věštkyně. Tuto pestrost rozmnožují i dramatické obrazy ze života s kresbou lidových obyčejů (Štědrý den, Dceřina kletba).
            Sbírkou prolíná přísný lidový názor mravní. Za proviněním přichází neúprosně trest. V křesťanské etice jej zmírňuje či odčiňuje pokání (Poklad, Svatební košile, Záhořovo lože). Erben vysoce ocenil společenské poslání ženy, zejména matky. Všechny skladby krom Záhořova lože mají své ženské hrdinky. A nad velikostí i nad úskalími mateřské lásky se kniha zamýšlí ve většině baladických básní: už v úvodní báji etymologické, v baladách Poklad, Polednice, Zlatý kolovrat, v slavném Vodníkovi, v bájích Vrba i Lilie, a velmi tvrdě v tragickém dialogu Dceřiny kletby. Erbenova poselství národu posud oslovují náš dnešek. V závěru Věštkyně čteme mj. : "Nenaříkejte, neštěstí a osud, že vás tak tvrdě potkaly, však naříkejte, že jste jimi posud rozumnější se nestali! " ... "Tisíc let ušlo, co své milé syny svornosti učil Svatopluk, však neproniknul dotud, do hodiny moudrého slova zlatý zvuk! "
            Výstavbě klasických balad se u Erbena učili mnozí naši epikové: Neruda, Hálek, ale i Wolker. Zpěvnost, obraznost i dramatičnost Kytice inspirovala naše největší skladatele i výtvarníky (Dvořák, Fibich, Martinů, Aleš, Zrzavý, Procházka, Tesař aj. ).</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>