<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class CharlesController extends AbstractController {
        
    public function charles(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>Charles Baudelaire</h1>
            <p>Život autora: Francouzský básník, prozaik a kritik, představitel symbolistického směru
            Autorovo další dílo: Verše, Sprostá mozaika, Život a dílo Felicity dAssis
            DALŠÍ AUTOŘI TOHOTO OBDOBÍ: Paul Verlaine, Arthur Rimbaud, Stéphane Mallarmé.
            </p>
            </body>
            </body>
            </html>'
        );
    }
}
?>