<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class StupneController extends AbstractController {
        
    public function stupne(): Response
    {

        return new Response(
            '<html>
            <head>
            </head>
            <body>
            
            <h1>451 stupňů Fahrenheita</h1>
            <p>451 stupnu farenheita<br>
            Literární druh a žánr: Science fiction<br>
            Literární směr: Dystopie<br>
            Slovní zásoba a jazyk: Prozaický jazyk, autor používá technické výrazy a odborné termíny<br>
            Hlavní postavy: Guy Montag, fabulátor, fireman, profesor Faber, Clarisse McClellan<br>
            Kompozice: Chronologický děj, časové a prostorové přeskoky<br>
            Prostor a čas: V budoucnosti v americkém městě<br>
            Význam sdělení (hlavní myšlenky díla): Kritika společnosti a jejího vztahu k knihám a vzdělání, varování před totalitou a omezováním svobody<br>
            SPOLEČENSKO-HISTORICKÉ POZADÍ: Studená válka, kritika totalitního režimu a jeho následků<br>
            AUTOR: Ray Bradbury<br>
            </p>
            <p>děj:<br>"451 stupňů Fahrenheita" od Raye Bradburyho je distopický román o společnosti, kde je knihovnictví zakázáno a knihy jsou spalovány. Hlavní postava, hasič Guy Montag, se postupně začne zamýšlet nad smyslem své práce a bojem proti knihám. Nakonec utíká s knihovnicí Clarisse a starým profesorem Faberem a společně se snaží najít nový život bez strachu z knih a totalitního režimu.</p>
            </body>
            </body>
            </html>'
        );
    }
}
?>