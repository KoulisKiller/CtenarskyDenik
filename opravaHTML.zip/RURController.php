<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class RURController extends AbstractController {
        
    public function rur(): Response
    {

        return new Response(
            '<!DOCTYPE html>
             <html lang="cs">
            <head>
			<title>R.U.R.</title>
            </head>
            <body>
            
            
            <p>Literární druh a žánr: Drama, sci-fi<br>
                Literární směr: Představitel sci-fi literatury a kybernetického realismu<br>
                Slovní zásoba a jazyk: Prozaický styl, využití technické terminologie, humor<br>
                Hlavní postavy: Domin, Harry Domin, Alquist, Helena Gloryová<br>
                Kompozice: Chronologický vývoj, využití dialogů a monologů<br>
                Prostor a čas: Futuristická společnost, blízká budoucnost<br>
                Význam sdělení (hlavní myšlenky díla): Kritika společnosti, otázky lidskosti, týkající se rozvinutí techniky, otázka životaschopnosti umělých bytostí<br>
                SPOLEČENSKO-HISTORICKÉ POZADÍ: Přelom 19. a 20. století, vývoj techniky, industriální revoluce, první světová válka<br>
                AUTOR: Karel Čapek, český spisovatel a dramatik<br>
            </p>
            <p>děj:<br>Děj se odehrává v továrně Rossumových Univerzálních Robotů (R.U.R. - Rossums Universal Robots) na blíže neurčeném ostrově.
            
                Předehra
                
                Do továrny na výrobu robotů přijíždí Helena Gloryová. Je šokována, jak se s roboty zachází a jejich naprostou lhostejností. Domin ji přesvědčí, aby si ho vzala a ona zůstává na ostrově.
                
                První dějství
                
                Děj se odehrává po deseti letech od předehry. Helena tuší, že něco není v pořádku, ale nikdo jí nic neřekne. Až z novin se dozvídá, že lidské ženy přestávají rodit děti. Ani ona nemá dítě a v rozčilení spaluje návod na výrobu robotů. Domin se domnívá, že má všechno pod kontrolou, ale místo běžné lodi s poštou přijede loď plná robotů. Roboti se vzbouřili proti lidem, chtějí je vyvraždit a vládnout světu, protože jsou lepší než lidé. Lidé z továrny chtějí utéct na loď Ultimus, ale roboti ji obsadí a začnou obsazovat i továrnu.
                
                Druhé dějství
                
                Roboti už mají i zbraně a stahují se kolem továrny. Dr. Gall se přiznává, že vyhověl žádostem Heleny a upravil některé roboty tak, aby měli vlastní rozum a emoce. Došlo však k tomu, že roboti si uvědomili svou pozici a chtějí vládnout. Chtějí s roboty uzavřít domluvu, že oni jim dají recept na jejich výrobu a roboti je nechají odejít, jenže Helena se přiznává, že recept spálila. Roboti už se dostávají dovnitř a postupně všechny zabíjí.
                
                Třetí dějství
                
                Roboti zabili všechny lidi kromě Alquista. Po něm teď chtějí, aby přišel na to, jak se roboti vyrábějí. On však neměl výrobu na starosti, a tak jen listuje v knihách a snaží se na něco přijít. Stále se mu však nedaří, až mu vůdce robotů Damon nařídí, aby nějakého robota rozpitval. Alquist si vybere jeho, ale stejně ničeho nedocílí. Později přistihne Helenu a Prima, jak spolu rozmlouvají, vyzkouší je, jestli jsou schopni se jeden pro druhého obětovat, zjistí, že jsou do sebe zamilovaní a nechá je jít. Pochopí, že oni jsou základem nového lidstva, novým Adamem a Evou.</p>
            </body>
            </html>'
        );
    }
}
?>